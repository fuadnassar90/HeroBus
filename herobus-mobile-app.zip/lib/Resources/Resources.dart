import 'package:herobus/Resources/Colors.dart';
import 'package:herobus/Resources/Strings.dart';

class R {
  static StringResources strings = StringResources();
  static ColorResources colors = ColorResources();
}
