class StringResources {
  //Main String Resources
  String appName = "App Name";
  String fontName = "Lato";

  //SplashPage String Resources
  List<String> splashScreenViewPagerHeader = [
    "Keep Your Trash Ready",
    "Your Keep Ready Trash",
    "Ready Trash Keep Keep"
  ];
  List<String> splashScreenViewPagerDescription = [
    "Keeping Your surrounding clean will Keep you Health Clean",
    "Clean Keeping surrounding clean will Keep you Health Clean",
    "Keeping Your surrounding clean will Keep you Health Clean"
  ];
  String getStarted = "Get Started";
  String logIn = "Log In";
  String forgetPass = "استرجعها الآن";
  String logInAsDriver = "Login As Driver";

  //Get Started Page
  String welcomeText = "مرحباً ";
  String welcomDescription = "يرجي ادخال رقم الهاتف للمتابعة";

  String userName = "Enter Your Full Name";
  String password = "Enter Your Password";

  String userNameTop = "User Name";
  String emailTop = "E - Mail";

  String mobileNumber = "Enter Your Mobile Number";
  String mobileNumberTop = "Mobile Number";

  String alreadyHaveAnAccount = "نسيت كلمة المرور ؟ ";
  String areYouWantToJoinUs = "إنضمام كسائق حافلة ؟ ";
  String JoinUs = "قدم طلبك الأن";
  //Login Page

  //Verification Page
  String done = "Done";
  String resendCode = "Resend Code";

  String phoneVerification = "Phone Verification";
  String sendVerificationto = "We send verification code to your number: ";

  //Verification Success
  String verificationSuccess = "Verification Success";

  //Home Tab

  String arrivalInformation = "Arrival Informations";
  String arrivalTime = "Arrival Time :";
  String date = "Date : ";
  String truckType = "Truck Type : ";

  //Profile Tab

  String personalInformation = "Personal Information";
  String logOut = "Log Out";

  //Cards Tab
  String amount = "Amount: ";
  String fine = "Fine: ";
  String pendingAmount = " Amount Pending";
  String payNow = "Pay Now";

  //History tab
  String transactionHistory = "Transaction history";
  String myHistory = "My History";
}
