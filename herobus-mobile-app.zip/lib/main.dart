import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:herobus/LoginAs.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:sizer/sizer.dart';
import 'SplashPage.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Firebase.initializeApp().then((value) {
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    FirebaseMessaging.onMessage.listen(_firebaseMessagingBackgroundHandler);
  });
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  cache.backgroundContainer = Container(
    decoration: BoxDecoration(
        color: HexColor('#05152e'),
        image: DecorationImage(
            image: AssetImage('assets/images/background_one.png'),
            fit: BoxFit.cover)),
  );

  runApp(MyApp());
  configLoading();
}
void configLoading() {
  EasyLoading.instance
    ..displayDuration = const Duration(milliseconds: 2000)
    ..indicatorType = EasyLoadingIndicatorType.cubeGrid
    ..loadingStyle = EasyLoadingStyle.dark
    ..indicatorSize = 45.0
    ..radius = 10.0
    ..progressColor = Colors.yellow
    ..backgroundColor = Colors.green
    ..indicatorColor = Colors.yellow
    ..textColor = Colors.yellow
    ..maskColor = Colors.blue.withOpacity(0.5)
    ..userInteractions = true
    ..dismissOnTap = false
    ..customAnimation = CustomAnimation();
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // runCode();
    print(DateTime.now().toString());
    return Sizer(builder: (context, orint, divise) {
      return MaterialApp(
        builder: EasyLoading.init(),
        title: 'Hero Bus',
        debugShowCheckedModeBanner: false,
        // theme: ThemeData(
        //   primarySwatch: Colors.blue,
        // ),
        home: LoginAs(),
        // home: Container(
        //   color: Colors.indigo,
        // decoration: BoxDecoration(color: Colors.black12),

        // ),
      );
    });
  }

  Widget Loading() {
    print('--------------- Loading init fcm ---------------');
  }

  Widget SomethingWentWrong() {
    print('--------------- SomethingWentWrong init fcm ---------------');
  }
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  if (message.notification.title.contains('تم قبول طلب')) {
    Navigator.push(
        cache.currentContext, MaterialPageRoute(builder: (c) => LoginAs()));
  }
  print(
      'there is new message title is:${message.notification.title} and body is:${message.notification.body}');
}
class CustomAnimation extends EasyLoadingAnimation {
  CustomAnimation();

  @override
  Widget buildWidget(
      Widget child,
      AnimationController controller,
      AlignmentGeometry alignment,
      ) {
    return Opacity(
      opacity: controller.value,
      child: RotationTransition(
        turns: controller,
        child: child,
      ),
    );
  }
}