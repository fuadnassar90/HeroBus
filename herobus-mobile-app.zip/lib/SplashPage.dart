// import 'dart:async';
//
// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:herobus/Backend/Cashe/cache.dart';
// import 'package:herobus/LoginAs.dart';
//
//
// class Splash extends StatefulWidget {
//   @override
//   _SplashState createState() => _SplashState();
// }
//
// class _SplashState extends State<Splash> {
//   startTimeout() {
//     return new Timer(Duration(seconds: 2), handleTimeout);
//   }
//
//   void handleTimeout() {
//     changeScreen();
//   }
//
//   changeScreen() async {
//     MyRouter.pushPageReplacement(
//       context,
//       LoginAs(),
//     );
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     startTimeout();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Stack(
//           children: [
//             Center(
//               child: Container(
//                 decoration: BoxDecoration(
//                     color: Color.fromRGBO(4, 20, 44,1),
//                     image: DecorationImage(
//                         image: AssetImage('assets/images/background_one.png'),fit: BoxFit.cover
//                     )),
//               ),
//             ),
//             Center(
//               child: Container(
//                 width: 100,
//                 decoration: BoxDecoration(
//                     image: DecorationImage(
//                       image: AssetImage('assets/images/ic_logo_500.png'),
//                     )),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
// class MyRouter{
//   static Future pushPage(BuildContext context, Widget page) {
//     var val = Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (BuildContext context) {
//           return page;
//         },
//       ),
//     );
//
//     return val;
//   }
//
//   static pushPageReplacement(BuildContext context, Widget page) {
//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(
//         builder: (BuildContext context) {
//           return page;
//         },
//       ),
//     );
//   }
// }