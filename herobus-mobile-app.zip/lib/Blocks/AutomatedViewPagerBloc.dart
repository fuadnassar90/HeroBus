import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';

class AutomatedViewPagerBloc extends Bloc<AutomatedViewPagerBlocEvent, int> {
  AutomatedViewPagerBloc(int initialState) : super(initialState);

  int get initialState => 0;
  bool looper = false;

  @override
  Stream<int> mapEventToState(AutomatedViewPagerBlocEvent event) async* {
    // TODO: implement mapEventToState
    switch (event) {
      case AutomatedViewPagerBlocEvent.start:
        looper = true;
        while (looper) {
          await new Future.delayed(new Duration(microseconds: 150));
          if (state >= 2) {
            yield 0;
          } else {
            yield state + 1;
          }
        }
        break;
      case AutomatedViewPagerBlocEvent.stop:
        looper = false;
        break;
    }
  }
}

enum AutomatedViewPagerBlocEvent { start, stop }
