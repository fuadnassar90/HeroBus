import 'package:flutter_bloc/flutter_bloc.dart';

class BottomMenuChooserBloc
    extends Bloc<BottomMenuChooserBlocEvent, BottomMenuChooserBlocEvent> {
  BottomMenuChooserBloc(BottomMenuChooserBlocEvent initialState): super(initialState);

  // TODO: implement initialState
  BottomMenuChooserBlocEvent get initialState =>
      BottomMenuChooserBlocEvent.home;

  @override
  Stream<BottomMenuChooserBlocEvent> mapEventToState(
      BottomMenuChooserBlocEvent event) async* {
    // TODO: implement mapEventToState
    yield event;
  }
}

enum BottomMenuChooserBlocEvent { home,profile }
