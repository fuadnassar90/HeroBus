import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
 import 'package:hexcolor/hexcolor.dart';
// import 'package:loading_animations/loading_animations.dart';
import 'Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'Backend/Cashe/preferances.dart';
import 'package:herobus/Blocks/AutomatedViewPagerBloc.dart';
import 'package:herobus/CustomWidgets/CustomTextField.dart';
import 'package:herobus/Driver/DriverSignin.dart';
import 'package:herobus/User/UserSelectRoute.dart';
import 'package:herobus/User/UserTabs.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart' as loc;
import 'package:permission_handler/permission_handler.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'CustomWidgets/CustomRaisedButton.dart';
import 'Resources/Resources.dart';
import 'package:sizer/sizer.dart';

class LoginAs extends StatefulWidget {
  @override
  _LoginAsState createState() => _LoginAsState();
}

class _LoginAsState extends State<LoginAs> {
  final _automatedViewPagerBlock = AutomatedViewPagerBloc(0);

  nav() async {
    await EasyLoading.show(
      status: null,
    );
    await DataInLocal.useValueToNavigate(context);
    await EasyLoading.dismiss();
  }

  var location = loc.Location();
  int selectedRadioTile;

  @override
  void initState() {
    super.initState();
    selectedRadioTile = 1;

    // _checkGps();
    nav();
  }

  setSelectedRadioTile(int val) {
    setState(() {
      selectedRadioTile = val;
      print(val);
    });
  }

  // Future _checkGps() async {
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.location,
  //   ].request();
  //   print(statuses[Permission.location]);
  //   if(!await location.serviceEnabled()){
  //     location.requestService();
  //   }
  // }
  @override
  Widget build(BuildContext context) {
    _automatedViewPagerBlock.add(AutomatedViewPagerBlocEvent.start);
    return Scaffold(
        body: Stack(
      children: <Widget>[
        Container(
          decoration: BoxDecoration(
            color: HexColor('#05152e'),
            image: DecorationImage(
                image: AssetImage('assets/images/background_one.png'),
                fit: BoxFit.cover),
          ),
        ),
        //cache.backgroundContainer,
        SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Directionality(
                  textDirection: TextDirection.rtl,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 4.w,
                      ),
                      Image.asset(
                        'assets/images/rec.png',
                        width: 10.w,
                      ),
                      SizedBox(
                        width: 4.w,
                      ),
                      Text(
                        ' تسجيل الدخول :',
                        style: GoogleFonts.almarai(
                          fontSize: 20.sp,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                // SizedBox(
                //   height: 70,
                // ),
                Padding(
                  padding: const EdgeInsets.only(left: 30.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      GestureDetector(
                        onTap: () async {
                          try {
                            nav();
                            await EasyLoading.show(status: null);
                            await AuthController.initUserLogin();
                            await EasyLoading.dismiss();
                            if (Urls.errorMessage == 'no') {
                              DataInLocal.get('userfirstlogin')
                                  .then((value) async {
                                if (value == '0' || value == '') {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => UserTabs()),
                                  );
                                } else {
                                  Navigator.pushAndRemoveUntil(
                                      context,
                                      MaterialPageRoute(
                                          builder: (c) => UserSelectRoute()),
                                      (route) => false);
                                  //
                                }
                              });
                            } else {
                              errorWhileOperation(
                                  errorMessage:
                                      "من فضلك تأكد من الاتصال بالانترنت",
                                  context: context,
                                  buttonText: 'اعد المحاولة',
                                  func: () {
                                    Navigator.pop(context);
                                  });
                            }
                          } catch (e) {
                            print('$e in get started');
                          }
                        },
                        child: Column(
                          children: [
                            Image.asset(
                              'assets/images/user.png',
                              width: 20.w,
                              height: 20.h,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              'مستخدم',
                              style: GoogleFonts.almarai(
                                fontSize: 15.sp,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 0,
                      ),
                      GestureDetector(
                        onTap: () async {
                          await EasyLoading.show(status: null);
                          // await AuthController.initUserLogin();
                          await EasyLoading.dismiss();
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (c) => DriverSignin()));
                        },
                        child: Column(
                          children: [
                            Image.asset(
                              'assets/images/bus.png',
                              width: 20.w,
                              height: 20.h,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              'سائق حافلة',
                              style: GoogleFonts.almarai(
                                fontSize: 15.sp,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        )
      ],
    ));
  }

  showSelectedMapTypeDialog() {
    showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          int selectedRadio = 0;
          bool selectedCheckList = false;
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'إختر نوع الخرائط',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 24),
                    ),
                    Directionality(
                      textDirection: TextDirection.rtl,
                      child: RadioListTile(
                        value: 0,
                        groupValue: selectedRadio,
                        title: Text(
                          "خرائط غوغل",
                        ),
                        onChanged: (int value) {
                          setState(() => selectedRadio = value);
                        },
                        activeColor: Colors.red,
                      ),
                    ),
                    Directionality(
                      textDirection: TextDirection.rtl,
                      child: RadioListTile(
                        value: 1,
                        groupValue: selectedRadio,
                        title: Text("خرائط ابل"),
                        onChanged: (int value) {
                          setState(() => selectedRadio = value);
                        },
                        activeColor: Colors.red,
                      ),
                    ),
                    // Directionality(
                    //     textDirection:
                    //         TextDirection.rtl,
                    //     child:
                    CheckboxListTile(
                      value: selectedCheckList,
                      title: Text(
                        'لا تسألني مجددا',
                        textDirection: TextDirection.rtl,
                      ),
                      onChanged: (val) {
                        setState(() => selectedCheckList = val);
                      },
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                      child: ButtonTheme(
                        height: 50,
                        minWidth: MediaQuery.of(context).size.width - 40,
                        child: CustomRaisedButton(
                          text: "المتابعة",
                          color: R.colors
                              .splashScreenViewPagerSelectedIndicatorColor,
                          onPressed: () async {},
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          );
        });
  }
}
