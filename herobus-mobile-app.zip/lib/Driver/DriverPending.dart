import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import '../Resources/LayoutController.dart';
import '../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/CustomWidgets/CustomArrowBack.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/CustomWidgets/CustomTextField.dart';
import 'package:herobus/Driver/Map/DriverMap.dart';
import 'package:herobus/LoginAs.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:url_launcher/url_launcher.dart';
class DriverPending extends StatefulWidget {
  @override
  _DriverPendingState createState() => _DriverPendingState();
}

class _DriverPendingState extends State<DriverPending>  with WidgetsBindingObserver {
  String name_route, no_plate, phone, pass;
  bool ok = false;

  @override
  Widget build(BuildContext context) {
    cache.currentContext=context;
    return Scaffold(
        body: Stack(
      children: <Widget>[
        cache.backgroundContainer,
        Container(
          width: MediaQuery.of(context).size.width,
          height: LayoutController.getHeight(
              (MediaQuery.of(context).size.height - 60),
              minHeight: 740),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                decoration: BoxDecoration(
                    color: R.colors.whiteMainColor,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(25),
                        topRight: Radius.circular(25))),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * .65,
                child:  Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      'assets/images/mail.png',
                      width: 100,
                      height: 100,
                    ),
                    Text(
                      // 'تم استلام طلب انضمامك',
                      'طلبك قيد المراجعة',
                      style: TextStyle(
                          color: R.colors.homeTextColor,
                          fontFamily: R.strings.fontName,
                          fontSize: 25,
                          fontWeight: FontWeight.w800),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 15,right: 15),
                      // widthFactor: 0.90,
                      child:  Text(
                          // 'عزيزنا العميل، نحن بصدد مراجعة طلبك\n سيتم معالجة الطلب خلال 24 ساعة\n نشكرك كونك جزء من Hero Bus',
                         'سيقوم فريقنا بالتواصل معك على رقم هاتفك نشكرك على كونك جزء من هيرو باص',
                          style: TextStyle(
                              color: R.colors.homeTextColor,
                              fontFamily: R.strings.fontName,
                              fontSize: 22,
                              fontWeight: FontWeight.w500),
                          textAlign: TextAlign.center,

                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    // CustomRaisedButton(
                    //   text: "رجوع",
                    //   borderColor: R.colors.splashScreenViewPagerSelectedIndicatorColor,
                    //   textColor: R.colors.splashScreenViewPagerSelectedIndicatorColor,
                    //   color: Colors.white,
                    //   onPressed: () {
                    //     setState(() {
                    //       ok = false;
                    //     });
                    //   },
                    // ),
                    IconButton(
                        icon: Image.asset(
                          'assets/images/whatsapp.png',
                          width: 50,
                          height: 50,
                        ),
                        padding: EdgeInsets.zero,
                        onPressed: () async {
                          String url = 'https://wa.me/+962785755223';
                          await canLaunch(url)
                              ? await launch(url)
                              : throw 'Could not launch $url';
                        }),
                  ],
                )
              ),
            ],
          ),
        ),
        // CustomArrowBack()
      ],
    ));
  }
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print('app state ${state.toString()}');
    if (state == AppLifecycleState.resumed) {
      print('app resumed');
      Navigator.push(
          cache.currentContext,
          MaterialPageRoute(
              builder: (c) =>
                  LoginAs()));
    }
}
}
