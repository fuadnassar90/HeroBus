import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/Backend/Cashe/preferances.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/CustomWidgets/CustomTextField.dart';
import 'package:herobus/Driver/DriverForgetPassword.dart';
import 'package:herobus/Driver/DriverRegistry.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:sizer/sizer.dart';

class DriverSignin extends StatefulWidget {
  @override
  _DriverSigninState createState() => _DriverSigninState();
}

class _DriverSigninState extends State<DriverSignin> {
  String username, password, phone;
  var _formKey = GlobalKey<FormState>();
  bool _isBluetoothOn = false;

  @override
  void dispose() {
    super.dispose();
    _formKey.currentState?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Form(
            key: _formKey,
            child: Stack(fit: StackFit.expand, children: <Widget>[
              cache.backgroundContainer,
              // IconButton(
              //   icon: Icon(Icons.arrow_back),
              //   onPressed: () {
              //     setState(() {
              //       _isBluetoothOn = !_isBluetoothOn;
              //     });
              //   },
              // ),
              Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  // mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      child: Container(
                        child: Image(
                          image: AssetImage('assets/images/ic_logo_500.png'),
                          width: 30.w,
                          fit: BoxFit.fill,
                        ),
                      ),
                      padding: EdgeInsets.fromLTRB(0, 40, 20, 0),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(20, 30, 20, 0),
                      child: Text(
                        R.strings.welcomeText,
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: R.strings.fontName,
                            fontSize: 22.sp,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(20, 15.0, 20, 0),
                      child: Text(
                        R.strings.welcomDescription,
                        textAlign: TextAlign.right,
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: R.strings.fontName,
                            fontSize: 15.sp,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                  width: MediaQuery.of(context).size.width,
                  height: 58.h,
                  bottom: 0,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(0, 10.h, 0, 0),
                    decoration: BoxDecoration(
                        color: R.colors.whiteMainColor,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(25),
                            topRight: Radius.circular(25))),
                    child: SingleChildScrollView(
                      child: Column(
                        children: <Widget>[
                          Container(
                              height: 8.h,
                              alignment: Alignment.center,
                              margin: EdgeInsets.fromLTRB(20, 30, 20, 0),
                              child: CustomTextField(
                                max: 9,
                                // suffix: Text('962+  '),

                                suffix: RichText(
                                  text: TextSpan(
                                    style: Theme.of(context).textTheme.body1,
                                    children: [
                                      TextSpan(
                                          text: '  962+ ',
                                          style: TextStyle(
                                              fontSize: 12.sp,
                                              fontWeight: FontWeight.bold)),
                                      WidgetSpan(
                                        child: Image(
                                          image: AssetImage(
                                              'assets/images/jordan_logo.png'),
                                          width: 5.w,
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                      TextSpan(text: ''),
                                    ],
                                  ),
                                ),
                                suffixStyle: TextStyle(),
                                onChange: (String val) {
                                  phone = val;
                                },
                                validator: (String val) {
                                  if (val.isEmpty)
                                    return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                  return null;
                                },
                                hintText: "ادخل رقم الهاتف   ",
                                hintStyle: TextStyle(fontSize: 10.sp),
                                topHintText: "رقم الهاتف",
                                textAlign: TextAlign.right,
                                keyboardType: TextInputType.number,
                              )),
                          Container(
                            height: 8.h,
                            margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                            child: CustomTextField(
                              onChange: (String val) {
                                password = val;
                              },
                              validator: (String val) {
                                if (val.isEmpty)
                                  return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                return null;
                              },
                              hintText: "ادخل كلمة المرور",
                              hintStyle: TextStyle(fontSize: 10.sp),
                              topHintText: "كلمة المرور",
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (c) => DriverForgetPassword(
                                            phoneNumber: phone,
                                          )));
                            },
                            child: Container(
                              padding: EdgeInsets.fromLTRB(0, 5, 35, 0),

                              width: MediaQuery.of(context).size.width,
                              // textDirection: TextDirection.rtl,
                              child: Text(
                                "لقد نسيت كلمة المرور",
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                    color: R.colors
                                        .splashScreenViewPagerSelectedIndicatorColor,
                                    fontFamily: R.strings.fontName,
                                    fontSize: 12.sp,
                                    fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            child: Padding(
                              padding:
                                  const EdgeInsets.fromLTRB(0, 18.0, 0, 15),
                              child: ButtonTheme(
                                height: 7.h,
                                minWidth:
                                    MediaQuery.of(context).size.width - 40,
                                child: CustomRaisedButton(
                                  text: "تسجيل الدخول",
                                  color: R.colors
                                      .splashScreenViewPagerSelectedIndicatorColor,
                                  onPressed: () async {
                                    // showSelectedMapTypeDialog();
                                    if (_formKey.currentState.validate()) {
                                      try {
                                        print(password);
                                        print(phone);
                                        await EasyLoading.show(status: null);
                                        await AuthController.initLoginDriver(
                                            phone: phone, pass: password);
                                        await EasyLoading.dismiss();
                                        Urls.errorMessage == 'no'
                                            ? await DataInLocal
                                                .useValueToNavigate(context)
                                            : errorWhileOperation(
                                                context: context,
                                                buttonText: 'اعد المحاولة',
                                                func: () {
                                                  Navigator.pop(context);
                                                });
                                      } on Exception catch (e) {
                                        print('$e in login as driver screen ');
                                      }
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (c) =>
                                          DriverRegistry())); // change to -> DriverRegistry()
                            },
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    "قدم طلبك الأن",
                                    style: TextStyle(
                                        color: R.colors
                                            .splashScreenViewPagerSelectedIndicatorColor,
                                        fontFamily: R.strings.fontName,
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w400),
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    "إنضمام كسائق حافلة ؟ ",
                                    style: TextStyle(
                                        color: R.colors.textHintColor,
                                        fontFamily: R.strings.fontName,
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w400),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ))
              // Stack(
              //   fit: StackFit.expand,
              //   alignment: AlignmentDirectional.bottomCenter,
              //   children: [
              //     Text(
              //       "tdfd",
              //       style: TextStyle(color: Colors.white, fontSize: 40,backgroundColor: Colors.black),
              //     )
              //   ],
              // )
            ])));
  }

  showSelectedMapTypeDialog() {
    showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          int selectedRadio = 0;
          bool selectedCheckList = false;
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'إختر نوع الخرائط',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 24),
                    ),
                    Directionality(
                      textDirection: TextDirection.rtl,
                      child: RadioListTile(
                        value: 0,
                        groupValue: selectedRadio,
                        title: Text(
                          "خرائط غوغل",
                        ),
                        onChanged: (int value) {
                          setState(() => selectedRadio = value);
                        },
                        activeColor: Colors.red,
                      ),
                    ),
                    Directionality(
                      textDirection: TextDirection.rtl,
                      child: RadioListTile(
                        value: 1,
                        groupValue: selectedRadio,
                        title: Text("خرائط ابل"),
                        onChanged: (int value) {
                          setState(() => selectedRadio = value);
                        },
                        activeColor: Colors.red,
                      ),
                    ),
                    // Directionality(
                    //     textDirection:
                    //         TextDirection.rtl,
                    //     child:
                    CheckboxListTile(
                      value: selectedCheckList,
                      title: Text(
                        'لا تسألني مجددا',
                        textDirection: TextDirection.rtl,
                      ),
                      onChanged: (val) {
                        setState(() => selectedCheckList = val);
                      },
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                      child: ButtonTheme(
                        height: 50,
                        minWidth: MediaQuery.of(context).size.width - 40,
                        child: CustomRaisedButton(
                          text: "المتابعة",
                          color: R.colors
                              .splashScreenViewPagerSelectedIndicatorColor,
                          onPressed: () async {},
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          );
        });
  }
}
