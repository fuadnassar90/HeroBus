import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:herobus/Driver/DriverPending.dart';
import '../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/CustomWidgets/CustomArrowBack.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/CustomWidgets/CustomTextField.dart';
import 'package:herobus/Driver/Map/DriverMap.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:sizer/sizer.dart';

class DriverRegistry extends StatefulWidget {
  @override
  _DriverRegistryState createState() => _DriverRegistryState();
}

class _DriverRegistryState extends State<DriverRegistry> {
  String name_route, no_plate, phone, pass;
  var _formKey = GlobalKey<FormState>();
  @override
  void dispose() {
    super.dispose();
    _formKey.currentState?.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        body: Form(
          key: _formKey,
          child: Stack(
            children: <Widget>[
              Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('assets/images/mask_profile.png'),
                        fit: BoxFit.cover)),
              ),
              Positioned(
                width: MediaQuery.of(context).size.width,
                height: 60.h,
                bottom: 0,
                child:

                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                          decoration: BoxDecoration(
                              color: R.colors.whiteMainColor,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(25),
                                  topRight: Radius.circular(25))),
                          width: MediaQuery.of(context).size.width,
                          height: 60.h,
                          child:ListView(
shrinkWrap: true,
                              children: <Widget>[
                                // Padding(
                                //   child: Container(
                                //     child: Image(
                                //       image: AssetImage('assets/images/ic_logo_500.png'),
                                //       width: 92,
                                //       height: 92,
                                //       fit: BoxFit.fill,
                                //     ),
                                //   ),
                                //   padding: EdgeInsets.fromLTRB(0, 40, 20, 0),
                                // ),
                                // Container(
                                //   margin: EdgeInsets.fromLTRB(0, 20, 20, 0),
                                //   child: Row(
                                //     mainAxisAlignment: MainAxisAlignment.end,
                                //     children: <Widget>[
                                //       Text(
                                //         'المعلومات الشخصية',
                                //         style: TextStyle(
                                //             color: R.colors.homeTextColor,
                                //             fontFamily: R.strings.fontName,
                                //             fontSize: 30,
                                //             fontWeight: FontWeight.w500),
                                //         textAlign: TextAlign.start,
                                //       ),
                                //     ],
                                //   ),
                                // ),
                                Container(
                                    height: 8.h,
                                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                                    child: CustomTextField(
                                      max: 9,
                                      preText: '+962  ',
                                      onChange: (String val) {
                                        phone = val;
                                      },
                                      validator: (String val) {
                                        if (val.isEmpty)
                                          return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                        return null;
                                      },
                                      hintText: 'رقم الهاتف',
                                      hintStyle: TextStyle(fontSize: 15),
                                      topHintText: 'ادخل رقم هاتفك',
                                      keyboardType: TextInputType.number,
                                    )),
                                Container(
                                    height: 8.h,
                                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                                    child: CustomTextField(
                                      onChange: (String val) {
                                        pass = val;
                                      },
                                      validator: (String val) {
                                        if (val.isEmpty)
                                          return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                        return null;
                                      },
                                      hintText: 'كلمة المرور',
                                      hintStyle: TextStyle(fontSize: 12),
                                      topHintText: 'ادخل كلمة المرور',
                                    )),
                                Container(
                                    height: 8.h,
                                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                                    child: CustomTextField(
                                      onChange: (String val) {
                                        name_route = val;
                                      },
                                      validator: (String val) {
                                        if (val.isEmpty)
                                          return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                        return null;
                                      },
                                      hintText: 'اسم الخط',
                                      hintStyle: TextStyle(fontSize: 12),
                                      topHintText: "ادخل مسار خط الباص",
                                    )),
                                Container(
                                    height: 8.h,
                                    margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                                    child: CustomTextField(
                                      onChange: (String val) {
                                        no_plate = val;
                                      },
                                      validator: (String val) {
                                        if (val.isEmpty)
                                          return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                        return null;
                                      },
                                      hintText: "ارقام لوحة الحافلة",
                                      hintStyle: TextStyle(fontSize: 12),
                                      topHintText: "ادخل ارقام لوحة الحافلة",
                                    )),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0, 5, 0, 0),
                                    child: ButtonTheme(
                                      height: 7.h,
                                      minWidth:
                                          MediaQuery.of(context).size.width - 40,
                                      child: CustomRaisedButton(
                                        text: "تقديم طلب",
                                        color: R.colors
                                            .splashScreenViewPagerSelectedIndicatorColor,
                                        onPressed: () async {
                                          if (_formKey.currentState.validate()) {
                                          try {
                                            await EasyLoading.show(status: null);
                                            await AuthController.registryDriver(
                                              name_route: name_route,
                                              no_plate: no_plate,
                                              phone: phone,
                                              pass: pass,
                                            );
                                            await EasyLoading.dismiss();
                                            Urls.errorMessage == 'no'
                                                ? Navigator.pushAndRemoveUntil(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (c) =>
                                                            DriverPending()),
                                                    (route) => false)
                                                : errorWhileOperation(
                                                    context: context,
                                                    buttonText: 'اعد المحاولة',
                                                    func: () {
                                                      Navigator.pop(context);
                                                    });
                                          } on Exception catch (e) {
                                            print(
                                                '-------- error in registry driver screen ');
                                          }
    }
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),





                ),
              ),
              CustomArrowBack()
            ],
          ),
        ));
  }
}
