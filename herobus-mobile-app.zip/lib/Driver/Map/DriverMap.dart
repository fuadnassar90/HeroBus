import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:adhara_socket_io/adhara_socket_io.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:herobus/Backend/Cashe/driverCache.dart';
import 'package:herobus/Backend/Cashe/map_style.dart';
import 'package:herobus/Backend/Cashe/userCache.dart';
import 'package:herobus/Driver/Map/driverMapCache.dart';
import '../../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/Driver/DriverMenu.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:ui' as ui;

import 'package:location/location.dart';
import 'package:permission_handler/permission_handler.dart' as permission;

class DriverMap extends StatefulWidget {
  DriverMap();

  @override
  _DriverMapState createState() => _DriverMapState();
}

double driverLat, driverLng, driverHead = 0;

class _DriverMapState extends State<DriverMap> {
  SocketIOManager manager;
  SocketIO socket;
  bool _isSocketConnected = false;
  String _mapStyle;
  List buses_temp_info = [];
  List users_temp_info = [];
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  Marker busMarker;
  String busMarkerID;
  Completer<GoogleMapController> _controller = Completer();
  StreamSubscription<LocationData> locationSubscription = null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: <Widget>[
        SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            color: R.colors.loginButtonColor,
            child: FutureBuilder(
              future: Future.delayed(Duration(milliseconds: 1000)),
              builder: (context, snapshot) {
                return GoogleMap(
                  myLocationButtonEnabled: false,
                  myLocationEnabled: false,
                  mapType: MapType.normal,
                  initialCameraPosition: driverMapCache.getInitCamera(),
                  markers: Set<Marker>.of(markers.values),
                  onMapCreated: (GoogleMapController controller) {
                    _controller.complete(controller);
                    setMapStyle();
                  },
                  polylines: driverMapCache.getPathPolyline(),
                  compassEnabled: false,
                  // onCameraMove: (CameraPosition position) {
                  //   print(position);
                  // },
                );
              },
            ),
          ),
        ),
        Positioned(
          bottom: 110,
          right: 10,
          width: 40,
          height: 40,
          child: FloatingActionButton(
            onPressed: () {
              _getCurrentLocation(moveCamera: true);
            },
            // label: Text(''),

            backgroundColor: Color(0xFFC2C2C2),
            child: Icon(
              Icons.location_on,
              color: Color(0xFF000000),
            ),
          ),
        ),
        Positioned(
          right: 0,
          child: Padding(
            padding: const EdgeInsets.only(top: 30, right: 10),
            child: IconButton(
              icon: Icon(
                Icons.menu,
                size: 40,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.push(
                    context, CupertinoPageRoute(builder: (c) => DriverMenu()));
              },
            ),
          ),
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Padding(
            // padding: EdgeInsets.fromLTRB(online ? 160 : 140, 80, 0, 0),
            // child:
            Container(
              padding: EdgeInsets.only(top: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    backgroundColor:
                        _isSocketConnected ? Colors.green : Colors.red,
                    radius: 10,
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Text(
                    _isSocketConnected ? 'متصل' : 'غير متصل',
                    style: TextStyle(
                      color: _isSocketConnected ? Colors.green : Colors.red,
                      fontWeight: FontWeight.w500,
                      fontSize: 30,
                    ),
                  ),
                ],
                // ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 40.0),
              child: GestureDetector(
                onTap: () {
                  // setState(() {
                  // online = !online;
                  if (_isSocketConnected) {
                    disconnectSocket();
                  } else {
                    connectSocket();
                  }
                  // sendMessage();
                  // });
                },
                child: Image.asset(
                  _isSocketConnected
                      ? 'assets/images/ic_stop_btn.png'
                      : 'assets/images/ic_start_btn.png',
                  width: 120,
                  height: 120,
                ),
              ),
            ),
          ],
        ),
      ],
    ));
  }

  @override
  void initState() {
    super.initState();
    _mapStyle = map_style.style;
    manager = SocketIOManager();
    driverMapCache.loadData();
    // print('token is:${cache.token} role is:${cache.role}');
  }

  @override
  void dispose() {
    disconnectSocket();
    super.dispose();
  }

  void setMapStyle() async {
    final GoogleMapController controller = await _controller.future;
    controller.setMapStyle(_mapStyle);
    setState(() {});
  }

  connectSocket() async {
    setState(() => _isSocketConnected = true);
    await _getCurrentLocation();
    if (driverLat != null && driverLng != null) {
      socket = await manager.createInstance(SocketOptions(Urls.API_SOCKET_URL,
          nameSpace: "/",
          query: {
            "id": driverCache.id_driver,
            "id_route": driverCache.id_route,
            "type": "driver",
            "location": "32.0296655, 36.0407233",
            "lat": "32.0296655",
            "lng": "36.0407233",
            "rotate": "0"
          },
          enableLogging: false,
          transports: [Transports.WEB_SOCKET]));
      socket.onConnect((data) {
        driverMapCache.pprint("success connected...");
        driverMapCache.pprint(data);
        // setState(() => _isSocketConnected = true);
      });
      socket.onConnectError((data) {
        setState(() => _isSocketConnected = false);
        driverMapCache.pprint(data);
      });
      socket.onConnectTimeout(driverMapCache.pprint);
      socket.onError((data) {
        setState(() => _isSocketConnected = false);
        driverMapCache.pprint(data);
      });
      socket.onDisconnect((data) {
        setState(() => _isSocketConnected = false);
        driverMapCache.pprint(data);
      });
      socket.on("map_drivers", (data) {
        print(data);

        String action = data['action'].toString();
        switch (action) {
          case 'update':
          case 'add':
            {
              List id_split = data['id'].toString().split('.');
              String busId = id_split[1];
              String socketId = id_split[2];
              double busLat = double.parse(data['lat'].toString());
              double busLng = double.parse(data['lng'].toString());
              double busRotate = double.parse(data['rotate'].toString());

              setState(() {
                if (busId == driverCache.id_driver) {
                  busMarkerID = socketId;
                  addCurrentMarker(socketId, busLat, busLng, busRotate);
                } else {
                  addMarker(socketId, busLat, busLng, busRotate);
                }
              });
            }
            break;
          case 'delete':
            {
              List id_split = data['id'].toString().split('.');
              String busId = id_split[1];
              String socketId = id_split[2];
              print('delete socketId: ' + socketId);
              markers.removeWhere((key, value) => key == MarkerId(socketId));
              setState(() {});
            }
            break;
        }
      });

      socket.on("map_users", (data) {
        driverMapCache.pprint(data);
        String action = data['action'].toString();
        switch (action) {
          case 'update':
          case 'add':
            {
              List id_split = data['id'].toString().split('.');
              String socketId = id_split[2];
              double userLat = double.parse(data['lat'].toString());
              double userLng = double.parse(data['lng'].toString());

              setState(() {
                addUserMarker(socketId, userLat, userLng);
              });
            }
            break;
          case 'delete':
            {
              List id_split = data['id'].toString().split('.');
              String socketId = id_split[2];
              print('delete socketId: ' + socketId);
              markers.removeWhere((key, value) => key == MarkerId(socketId));
              setState(() {});
            }
            break;
        }
      });
      socket.connect();
      AuthController.initMapDriver(id_route: driverCache.id_route)
          .whenComplete(() {
        print('run initMapDriver whenComplete2');
        buses_temp_info = userCache.buses_temp_info;
        users_temp_info = userCache.users_temp_info;
        print('buses_temp_info length:${buses_temp_info.length}');
        buses_temp_info.forEach((element) {
          String socketId = element[0].toString();
          List splitCoord = element[1].toString().split(',');
          // String name = splitCoord[0].toString();
          double busLat = double.parse(splitCoord[1].toString());
          double busLng = double.parse(splitCoord[2].toString());
          double busRotate = double.parse(splitCoord[3].toString());
          // String running = splitCoord[4].toString();
          print('add socketId:$socketId');
          if (!socketId.contains('.' + driverCache.id_driver + '.')) {
            addMarker(socketId, busLat, busLng, busRotate);
          }
        });
        users_temp_info.forEach((element) {
          String userId = element[0].toString();
          List splitCoord = element[1].toString().split(',');
          double userLat = double.parse(splitCoord[0].toString());
          double userLng = double.parse(splitCoord[1].toString());
          addUserMarker(userId, userLat, userLng);
        });
      });
    } else {
      setState(() => _isSocketConnected = false);
    }

  }

  sendEmitNewLocaion({driverLat, driverLng, driverHead}) {
    if (socket != null) {
      socket.emit("map_drivers", [
        {
          "id": driverCache.id_driver,
          "id_route": driverCache.id_route,
          "type": "driver",
          "lat": driverLat,
          "lng": driverLng,
          "rotate": driverHead,
          "running": "متوقف", /// change this line for متحرك او متوقف حسب حالة الحافلة

        },
      ]);
    }
  }

  disconnectSocket() async {
    setState(() {
      _isSocketConnected = false;
      markers.clear();
      locationSubscription.cancel(); /// error: The method 'cancel' was called on null  <--- should fix it
    });
    await manager.clearInstance(socket);
    // setState(() => _isProbablyConnected = false);
  }

  void addMarker(@required String makerID, @required double lat,
      @required double lng, @required double rotate) async {
    final Uint8List markerIcon =
        await driverMapCache.getBytesFromAsset('assets/images/ic_bus.png', 120);
    markers[MarkerId(makerID)] = Marker(
      flat: true,
      rotation: rotate,
      markerId: MarkerId(makerID),
      position: LatLng(lat, lng),
      icon: BitmapDescriptor.fromBytes(markerIcon),
    );
  }

  void addCurrentMarker(@required String makerID, @required double lat,
      @required double lng, @required double rotate) async {
    // BitmapDescriptor bitmapDescriptor = await BitmapDescriptor.fromAssetImage(
    //     ImageConfiguration(size: Size(10, 10)), "assets/images/car.png");

    final Uint8List markerIcon = await driverMapCache.getBytesFromAsset(
        'assets/images/ic_bus_blue.png', 120);
    busMarker = Marker(
      flat: true,
      rotation: driverHead,
      markerId: MarkerId(makerID),
      position: LatLng(driverLat, driverLng),
      icon: BitmapDescriptor.fromBytes(markerIcon),
      draggable: false,
      zIndex: 2,
      anchor: Offset(0.5, 0.5),
    );
    markers[MarkerId(makerID)] = busMarker;
  }

  void addUserMarker(@required String makerID, @required double lat,
      @required double lng) async {
    // BitmapDescriptor bitmapDescriptor = await BitmapDescriptor.fromAssetImage(
    //     ImageConfiguration(size: Size(10, 10)), "assets/images/car.png");

    final Uint8List markerIcon = await driverMapCache.getBytesFromAsset(
        'assets/images/ic_persone_location.png', 60);
    markers[MarkerId(makerID)] = Marker(
      markerId: MarkerId(makerID),
      position: LatLng(lat, lng),
      icon: BitmapDescriptor.fromBytes(markerIcon),
    );
  }

  void _getCurrentLocation({bool moveCamera = false}) async {
    var location = new Location();
    Map<permission.Permission, permission.PermissionStatus> statuses = await [
      permission.Permission.location,
    ].request();
    print(statuses[permission.Permission.location]);
    if (!await location.serviceEnabled()) {
      // setState(() {
      //   _isSocketConnected = true;
      // });
      location.requestService().whenComplete(() {print('enable gps done');connectSocket();});
    } else {
      final GoogleMapController controller = await _controller.future;
      LocationData currentLocation;

      try {
        currentLocation = await location.getLocation();
      } on Exception {
        currentLocation = null;
      }
      driverLat = currentLocation.latitude;
      driverLng = currentLocation.longitude;
      driverHead = currentLocation.heading;
      print(
          'driverLat:$driverLat driverLng:$driverLng driverHead:$driverHead ');
      if (moveCamera) {
        controller.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(
            bearing: 0,
            target: LatLng(currentLocation.latitude, currentLocation.longitude),
            zoom: 17.0,
          ),
        ));
      }
      // if (locationSubscription == null) {
      locationSubscription =
          location.onLocationChanged.listen((LocationData currentLocation) {
        setState(() {
          driverLat = currentLocation.latitude;
          driverLng = currentLocation.longitude;
          driverHead = currentLocation.heading;
          // markers[MarkerId(busMarkerID)]=busMarker;

          if (busMarkerID != null && _isSocketConnected == true) {
            // print('busMarkerID:$busMarkerID');
            MarkerId id = MarkerId(busMarkerID);
            markers[id] = markers[id].copyWith(
                positionParam: LatLng(driverLat, driverLng),
                rotationParam: driverHead,
                anchorParam: Offset(0.5, 0.5),
                draggableParam: false,
                zIndexParam: 2);
          } else {
            print('busMarkerID it is equal null');
          }
          //
          // print(id);
          // markers[id]= markers[id].copyWith(positionParam:LatLng(driverLat,driverLng),rotationParam: driverHead);
        });
        // print(
        //     'new location driverLat:$driverLat driverLng:$driverLng driverHead:$driverHead ');
        sendEmitNewLocaion(
            driverLat: driverLat, driverLng: driverLng, driverHead: driverHead);
      });
      // } else {
      //   locationSubscription.resume();
      // }
    }
  }
}
