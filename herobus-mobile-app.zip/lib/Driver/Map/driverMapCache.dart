import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:herobus/Backend/Cashe/driverCache.dart';
import 'dart:ui' as ui;
class driverMapCache{


  static double _lat, _lng, _zoom, _bearing, _tilt,_driverLat, _driverLng, _driverHead = 0;
  static List<LatLng> _coords = [];

  static void loadData(){
    _lat = double.parse(driverCache.map_init_coord.split(',')[0].toString());
    _lng = double.parse(driverCache.map_init_coord.split(',')[1].toString());
    _zoom = double.parse(driverCache.map_init_zoom.toString());
    _bearing = double.parse(driverCache.map_init_bearing.toString());
    _tilt = double.parse(driverCache.map_init_tilt.toString());
    // print('''$lat+'  :   '+$lng+'  :     '+$zoom+'  :   '+$bearing+'  :   '+$tilt+'  :   ''');
    List route = driverCache.map_init_path;
    for (String coord in route) {
      var split = coord.split(',');
      double lat = double.parse(split[0]);
      double lng = double.parse(split[1]);
      _coords.add(LatLng(lat, lng));
    }

  }
  static CameraPosition getInitCamera(){
     final CameraPosition _kGooglePlex = CameraPosition(
        target: LatLng(_lat, _lng), zoom: _zoom, bearing: _bearing, tilt: _tilt);
    return _kGooglePlex;
  }

  static Set<Polyline> getPathPolyline(){
    Set<Polyline> polylineSet = {};
    Polyline polyline = Polyline(
        polylineId: PolylineId('1'),
        points: _coords,
        color: Colors.blueAccent,
        jointType: JointType.round,
        width: 5,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
        geodesic: true);
    polylineSet.add(polyline);
    return polylineSet;
  }
  static Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
        targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))
        .buffer
        .asUint8List();
  }

  static pprint(data) {
      if (data is Map) {
        data = json.encode(data);
      }
      print(data);
  }





}