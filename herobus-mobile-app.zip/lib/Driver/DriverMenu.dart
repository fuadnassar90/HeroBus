import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:herobus/Backend/Cashe/driverCache.dart';
import '../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/Backend/Cashe/preferances.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/CustomWidgets/CustomTextField.dart';
import 'package:herobus/LoginAs.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:url_launcher/url_launcher.dart';
import 'DriverRegistry.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:sizer/sizer.dart';

class DriverMenu extends StatefulWidget {
  DriverMenu();

  @override
  _DriverMenuState createState() => _DriverMenuState();
}

class _DriverMenuState extends State<DriverMenu> {
  List drivers = [];
  String phone, pass;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
            children: [
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 20, 0, 0),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: Colors.black, width: 0.3),
                      ),
                      child: Center(
                        child: Icon(
                          Icons.arrow_back_ios,
                          size: 8.w,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text.rich(
                    TextSpan(text: '\n:عدد السائقين الحاليين\n', children: [
                      TextSpan(
                        text: '                   ${drivers.length}/5',
                      )
                    ]),
                    style: GoogleFonts.almarai(
                      color: Color(0xFF3D5E87),
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 2.h,
              ),
              ListView.builder(
                primary: false,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: driverCache.drivers.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 10),
                    child: Container(
                      height: 65,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        shape: BoxShape.rectangle,
                        color: R.colors.textBackgroundColor,
                      ),
                      child: Row(
                        children: [
                          Text(
                            '+962 ',
                            style: TextStyle(
                              color: Color(0xFF3D5E87).withOpacity(0.7),
                            ),
                          ),
                          SizedBox(
                            width: 2,
                          ),
                          Text(
                            drivers[index]['phone']
                                .toString()
                                .replaceFirst('+962', ''),
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Spacer(
                            flex: 2,
                          ),
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(bottom: 38.0),
                                child: Text(
                                  'رقم الهاتف',
                                  style: TextStyle(
                                    color: Color(0xFF3D5E87).withOpacity(0.7),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 34,
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.close,
                                  color: Colors.red,
                                  size: 30,
                                ),
                                onPressed: () async {
                                  print('delete driver: ' +
                                      drivers[index]['id'].toString());
                                  try {
                                    await EasyLoading.show(status: null);
                                    await AuthController.deleteDriver(
                                        id: drivers[index]['id'].toString());
                                    await EasyLoading.dismiss();
                                    if (Urls.errorMessage != 'no') {
                                      errorWhileOperation(
                                          context: context,
                                          buttonText: 'اعد المحاولة',
                                          func: () {
                                            Navigator.pop(context);
                                          });
                                    } else {
                                      setState(() {
                                        drivers.removeAt(index);
                                      });
                                    }
                                  } on Exception catch (e) {
                                    print('$e in login as driver screen ');
                                  }
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(0, 18.0, 0, 50),
                  child: ButtonTheme(
                    height: 7.h,
                    minWidth: MediaQuery.of(context).size.width - 40,
                    child: CustomRaisedButton(
                      text: "اضافة المزيد من السائقين",
                      color:
                          R.colors.splashScreenViewPagerSelectedIndicatorColor,
                      onPressed: () async {
                        // Navigator.push(context,
                        //     MaterialPageRoute(builder: (c) => DriverRegistry()));
                        showDialog<void>(
                            context: context,
                            builder: (BuildContext context) {
                              int selectedRadio = 0;
                              bool selectedCheckList = false;
                              return AlertDialog(
                                content: StatefulBuilder(
                                  builder: (BuildContext context,
                                      StateSetter setState) {
                                    return Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          'ادخل رقم الهاتف وكلمة المرور للسائق الجديد',
                                          textAlign: TextAlign.right,
                                          style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              fontSize: 12.sp),
                                        ),
                                        Container(
                                            height: 7.h,
                                            margin: EdgeInsets.fromLTRB(
                                                0, 20, 0, 0),
                                            child: CustomTextField(
                                              max: 9,
                                              // suffix: Text('962+  '),

                                              suffix: RichText(
                                                text: TextSpan(
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .body1,
                                                  children: [
                                                    TextSpan(text: '  962+ '),
                                                    WidgetSpan(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .symmetric(
                                                                horizontal:
                                                                    2.0),
                                                        child: Image(
                                                          image: AssetImage(
                                                              'assets/images/jordan_logo.png'),
                                                          width: 16,
                                                          height: 16,
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                    ),
                                                    TextSpan(text: ''),
                                                  ],
                                                ),
                                              ),
                                              suffixStyle: TextStyle(),
                                              onChange: (String val) {
                                                phone = val;
                                              },
                                              validator: (String val) {
                                                if (val.isEmpty)
                                                  return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                                return null;
                                              },
                                              hintText: "رقم الهاتف",
                                              hintStyle:
                                                  TextStyle(fontSize: 12),
                                              topHintText: "ادخل رقم الهاتف   ",
                                              textAlign: TextAlign.right,
                                              keyboardType:
                                                  TextInputType.number,
                                            )),
                                        Container(
                                          height: 7.h,
                                          margin:
                                              EdgeInsets.fromLTRB(0, 20, 0, 0),
                                          child: CustomTextField(
                                            onChange: (String val) {
                                              pass = val;
                                            },
                                            validator: (String val) {
                                              if (val.isEmpty)
                                                return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                              return null;
                                            },
                                            hintText: "كلمة المرور",
                                            hintStyle: TextStyle(fontSize: 12),
                                            topHintText: "ادخل كلمة المرور",
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              0, 20, 0, 0),
                                          child: ButtonTheme(
                                            height: 7.h,
                                            minWidth: MediaQuery.of(context)
                                                    .size
                                                    .width -
                                                40,
                                            child: CustomRaisedButton(
                                              text: "إضافة السائق",
                                              color: R.colors
                                                  .splashScreenViewPagerSelectedIndicatorColor,
                                              onPressed: () async {
                                                if (phone.length < 8) {
                                                  Fluttertoast.showToast(
                                                    msg:
                                                        'خطأ: رقم الهاتف غير صحيح',
                                                    toastLength:
                                                        Toast.LENGTH_SHORT,
                                                    gravity:
                                                        ToastGravity.CENTER,
                                                    timeInSecForIosWeb: 1,
                                                    backgroundColor:
                                                        Color(0xff1c2834),
                                                    textColor: Colors.white,
                                                  );
                                                } else if (pass.length < 1) {
                                                  Fluttertoast.showToast(
                                                    msg:
                                                        'خطأ: لم تقم بادخال كلمة مرور',
                                                    toastLength:
                                                        Toast.LENGTH_SHORT,
                                                    gravity:
                                                        ToastGravity.CENTER,
                                                    timeInSecForIosWeb: 1,
                                                    backgroundColor:
                                                        Color(0xff1c2834),
                                                    textColor: Colors.white,
                                                  );
                                                } else if (drivers.length < 5) {
                                                  try {
                                                    await EasyLoading.showProgress(
                                                        0,
                                                        status:
                                                            '${(0 * 100).toStringAsFixed(0)}%');
                                                    await AuthController
                                                        .addDriver(
                                                            phone: phone,
                                                            pass: pass);
                                                    await EasyLoading.dismiss();
                                                    if (Urls.errorMessage !=
                                                        'no') {
                                                      errorWhileOperation(
                                                          context: context,
                                                          buttonText:
                                                              'اعد المحاولة',
                                                          func: () {
                                                            Navigator.pop(
                                                                context);
                                                          });
                                                    } else {
                                                      Navigator.pop(context);
                                                      print(
                                                          driverCache.drivers);
                                                      setState(() {
                                                        drivers =
                                                            driverCache.drivers;
                                                      });
                                                    }
                                                  } on Exception catch (e) {
                                                    print(
                                                        '$e in login as driver screen ');
                                                  }
                                                } else {
                                                  errorWhileOperation(
                                                      context: context,
                                                      errorMessage:
                                                          'الخطأ: لا يمكنك إضافة اكثر من 5 سائقين',
                                                      buttonText: 'حسننا',
                                                      func: () {
                                                        Navigator.pop(context);
                                                      });
                                                }
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                ),
                              );
                            });
                      },
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        IconButton(
                            icon: Image.asset(
                              'assets/images/facebook.png',
                              width: 12.w,
                              height: 12.h,
                            ),
                            padding: EdgeInsets.zero,
                            onPressed: () async {
                              String url = 'https://fb.me/herobusltd';
                              await canLaunch(url)
                                  ? await launch(url)
                                  : throw 'Could not launch $url';
                            }),
                        IconButton(
                            icon: Image.asset(
                              'assets/images/whatsapp.png',
                              width: 12.w,
                              height: 12.h,
                            ),
                            padding: EdgeInsets.zero,
                            onPressed: () async {
                              String url = 'https://wa.me/+962785755223';
                              await canLaunch(url)
                                  ? await launch(url)
                                  : throw 'Could not launch $url';
                            }),
                        IconButton(
                            icon: Image.asset(
                              'assets/images/youtube.png',
                              width: 12.w,
                              height: 12.h,
                            ),
                            padding: EdgeInsets.zero,
                            onPressed: () async {
                              String url =
                                  'https://www.youtube.com/channel/UCaOkpeNfxvFAH4ND--hmG2A';
                              await canLaunch(url)
                                  ? await launch(url)
                                  : throw 'Could not launch $url';
                            }),
                      ],
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(0, 18.0, 0, 30),
                        child: ButtonTheme(
                          height: 7.h,
                          minWidth: MediaQuery.of(context).size.width - 40,
                          child: CustomRaisedButton(
                            text: "تسجيل الخروج",
                            borderColor: R.colors
                                .splashScreenViewPagerSelectedIndicatorColor,
                            textColor: R.colors
                                .splashScreenViewPagerSelectedIndicatorColor,
                            color: Colors.white,
                            onPressed: () async {
                              // await EasyLoading.show(status: 'Logging out..');
                              // await AuthController.logout(token: widget.token);
                              // await EasyLoading.dismiss();
                              // Urls.errorMessage == 'no'
                              //     ? Navigator.pushAndRemoveUntil(
                              //         context,
                              //         MaterialPageRoute(
                              //             builder: (c) => LoginAs()),
                              //         (route) => false)
                              //     : errorWhileOperation(
                              //         errorMessage: Urls.errorMessage,
                              //         context: context,
                              //         buttonText: 'Try Again',
                              //         func: () {
                              //           Navigator.pop(context);
                              //         });
                              cache.token = '';
                              await DataInLocal.saveInLocal(
                                  token: '0', role: '0',id:'0');
                              Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(builder: (c) => LoginAs()),
                                  (route) => false);
                            },
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    drivers = driverCache.drivers;
  }

  // void _launchURL(String url) async =>
  //     await canLaunch(url) ? await launch(url) : throw 'Could not launch $url';

  launchURL(String url) async {
    print('click and show $url');
    await canLaunch(url) ? await launch(url) : throw 'Could not launch $url';
  }
}
