import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:herobus/Backend/Cashe/preferances.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/dialogs/error.dart';
import '../Resources/LayoutController.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:herobus/Blocks/AutomatedViewPagerBloc.dart';
import 'package:herobus/Driver/Map/DriverMap.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:image_fade/image_fade.dart';

import 'DriverSignin.dart';

class DriverVerificationSuccess extends StatefulWidget {
  DriverVerificationSuccess({Key key}) : super(key: key);

  @override
  _DriverVerificationSuccessState createState() =>
      _DriverVerificationSuccessState();
}

class _DriverVerificationSuccessState extends State<DriverVerificationSuccess> {
  final _automatedViewPagerBlock = AutomatedViewPagerBloc(0);

  @override
  Widget build(BuildContext context) {
    _automatedViewPagerBlock.add(AutomatedViewPagerBlocEvent.start);
    return Scaffold(
        body: Stack(
      children: <Widget>[
        cache.backgroundContainer,
        SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height:
                LayoutController.getHeight(MediaQuery.of(context).size.height),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                    Padding(
                      child: Container(
                        height: 80,
                        child: ImageFade(
                          image: AssetImage(
                              'assets/images/verification_success.png'),
                          fadeDuration: Duration(milliseconds: 500),
                          fadeCurve: Curves.easeInBack,
                        ),
                      ),
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(0, 40.0, 0, 100),
                      child: Text(
                        'تم التحقق بنجاح',
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: R.strings.fontName,
                            fontSize: 18,
                            fontWeight: FontWeight.w500),
                      ),
                    )

              ],
            ),
          ),
        )
      ],
    ));
  }

  void startHomeTab() async {
    await new Future.delayed(new Duration(seconds: 1));
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(builder: (context) => MainHomeTabPage()),
    // );
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //       builder: (context) => DriverSignin()),
    // );
    Urls.errorMessage == 'no'
        ? await DataInLocal
        .useValueToNavigate(context)
        : errorWhileOperation(
        context: context,
        buttonText: 'اعد المحاولة',
        func: () {
          Navigator.pop(context);
        });
  }

  @override
  void initState() {
    super.initState();
    startHomeTab();
  }
}
