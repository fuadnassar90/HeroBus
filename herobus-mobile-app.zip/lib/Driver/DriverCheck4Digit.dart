import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../Resources/LayoutController.dart';
import '../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/Blocks/UpdateOtpBloc.dart';
import 'package:herobus/CustomWidgets/CustomArrowBack.dart';
import 'package:herobus/CustomWidgets/CustomNumberPad.dart';
import 'package:herobus/CustomWidgets/CustomOtpTextField.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/Driver/DriverUpdatePassword.dart';
import 'package:herobus/Driver/DriverVerificationSuccess.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:sizer/sizer.dart';
class DriverCheck4Digit extends StatefulWidget {
  DriverCheck4Digit({@required this.phoneNumber});
  final String phoneNumber;

  @override
  _DriverCheck4DigitState createState() => _DriverCheck4DigitState();
}

class _DriverCheck4DigitState extends State<DriverCheck4Digit> {
  final UpdateOtpBloc counterBloc =
  UpdateOtpBloc(["•", "•", "•", "•", "•", "•"]);
  List list = [];
  String code;
  resendCode() async {
    await AuthController.forgetPassword(phone: widget.phoneNumber);
    Urls.errorMessage == 'no'
        ? print('Code sent')
        : errorWhileOperation(
        errorMessage: 'Code not sent try again',
        context: context,
        buttonText: 'Try Again',
        func: () {
          Navigator.pop(context);
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Form(
            child: Stack(fit: StackFit.expand, children: <Widget>[
              cache.backgroundContainer,

              Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  // mainAxisAlignment: MainAxisAlignment.start,
                  children: [

                    Padding(
                      padding: EdgeInsets.fromLTRB(20, 50, 30, 0),
                      child: Text(
                        'التحقق من رقم الهاتف',
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: R.strings.fontName,
                            fontSize: 18.sp,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(20, 15.0,20, 0),
                      child: Text(
                        ":" +"قمنا بإرسال رسالة تحقق الي رقمك التالي " +"\n"+
                            (widget.phoneNumber ?? ""),
                        textAlign: TextAlign.right,
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: R.strings.fontName,
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w300),
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.fromLTRB(20, 30, 20, 0),
                        child: CustomOtpTextField(
                          counterBloc: counterBloc,
                        )),
                  ],
                ),
              ),
              Positioned(
                  width: MediaQuery.of(context).size.width,
                  bottom: 0,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(0, 50, 0, 0),
                    decoration: BoxDecoration(
                        color: R.colors.whiteMainColor,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(25),
                            topRight: Radius.circular(25))),
                    width: MediaQuery.of(context).size.width,
                    child: SingleChildScrollView(
                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                            child: CustomNumberPad(
                              onButtonClicked: (String str) {
                                if (str != '<') {
                                  list.add(str);
                                } else {
                                  list.isEmpty
                                      ? print('list is empty')
                                      : list.removeLast();
                                }
                                counterBloc.add(UpdateOtpBlocEvent(string: str));
                                print('my list $list');
                              },
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(0, 5.0, 0, 10),
                              child: ButtonTheme(
                                height: 7.h,
                                minWidth: MediaQuery.of(context).size.width - 40,
                                child: CustomRaisedButton(
                                  text: "تآكيد",
                                  color: R.colors
                                      .splashScreenViewPagerSelectedIndicatorColor,
                                  onPressed: () async {
                                    code = list.join();
                                    try {
                                      await EasyLoading.show(status: 'Checking..');
                                      await AuthController.checkCode(
                                          phone: widget.phoneNumber,
                                          code: code,
                                          hash: Urls.hashSMS);
                                      await EasyLoading.dismiss();
                                      Urls.errorMessage == 'no'
                                          ? Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                            // DriverVerificationSuccess(
                                            // ),
                                            DriverUpdatePassword()
                                        ),
                                      )
                                          : errorWhileOperation(
                                          errorMessage:
                                          "من فضلك تأكد من المعلومات التي ادخلتها",
                                          context: context,
                                          buttonText: 'اعد المحاولة',
                                          func: () {
                                            Navigator.pop(context);
                                          });
                                    } catch (e) {
                                      print(e);
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),
                  )),
              CustomArrowBack()
              // Stack(
              //   fit: StackFit.expand,
              //   alignment: AlignmentDirectional.bottomCenter,
              //   children: [
              //     Text(
              //       "tdfd",
              //       style: TextStyle(color: Colors.white, fontSize: 40,backgroundColor: Colors.black),
              //     )
              //   ],
              // )
            ])));
  }
}
