import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/CustomWidgets/CustomTextField.dart';
import 'package:herobus/Driver/Map/DriverMap.dart';
import 'package:herobus/Driver/DriverVerificationSuccess.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
class DriverUpdatePassword extends StatefulWidget {

  DriverUpdatePassword();
  @override
  _DriverUpdatePasswordState createState() => _DriverUpdatePasswordState();
}

class _DriverUpdatePasswordState extends State<DriverUpdatePassword> {
  String password, password2;
  var _formKey = GlobalKey<FormState>();
  @override
  void dispose() {
    super.dispose();
    _formKey.currentState?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print(MediaQuery.of(context).size.height);
    return WillPopScope(
      onWillPop: () => Future.value(false),
      child: Scaffold(
          body: Form(
              key: _formKey,
              child: Stack(fit: StackFit.expand, children: <Widget>[
                cache.backgroundContainer,
                // IconButton(
                //   icon: Icon(Icons.arrow_back),
                //   onPressed: () {
                //     setState(() {
                //       _isBluetoothOn = !_isBluetoothOn;
                //     });
                //   },
                // ),
                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    // mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        child: Container(
                          child: Image(
                            image: AssetImage('assets/images/ic_logo_500.png'),
                            width: 92,
                            height: 92,
                            fit: BoxFit.fill,
                          ),
                        ),
                        padding: EdgeInsets.fromLTRB(0, 40, 20, 0),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(0, 50, 20, 0),
                        child: Text(
                          'كلمة المرور الجديده',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: R.strings.fontName,
                              fontSize: 30,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(20, 15.0, 20, 0),
                        child: Text(
                          'يرجي ادخال كلمة مرور جديدة للمتابعة',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: R.strings.fontName,
                              fontSize: 20,
                              fontWeight: FontWeight.w300),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                    width: MediaQuery.of(context).size.width,
                    bottom: 0,
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 50, 0, 0),
                      decoration: BoxDecoration(
                          color: R.colors.whiteMainColor,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(25),
                              topRight: Radius.circular(25))),
                      width: MediaQuery.of(context).size.width,
                      child: SingleChildScrollView(
                        child: Column(
                          children: <Widget>[
                            Container(
                                margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                                child: CustomTextField(
                                  onChange: (String val) {
                                    password = val;
                                  },
                                  validator: (String val) {
                                    if (val.isEmpty)
                                      return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                    if (val != password2)
                                      return 'كلمتان المرور غير متطابقين';
                                    return null;
                                  },
                                  hintText: 'كلمة المرور الجديدة',
                                  topHintText: 'ادخل كلمة مرور جديدة' ,
                                )),
                            Container(
                                margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
                                child: CustomTextField(
                                  onChange: (String val) {
                                    password2 = val;
                                  },
                                  validator: (String val) {
                                    if (val.isEmpty)
                                      return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                    if (val != password)
                                      return 'كلمتان المرور غير متطابقين';
                                    return null;
                                  },
                                  hintText:'كلمة المرور الجديدة' ,
                                  topHintText: 'اعادة ادخال كلمة المرور',
                                )),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: Padding(
                                padding:
                                const EdgeInsets.fromLTRB(0, 20.0, 0, 20),
                                child: ButtonTheme(
                                  height: 50,
                                  minWidth:
                                  MediaQuery.of(context).size.width - 40,
                                  child: CustomRaisedButton(
                                    text: "متابعة",
                                    color: R.colors
                                        .splashScreenViewPagerSelectedIndicatorColor,
                                    onPressed: () async {
                                      if (_formKey.currentState.validate()) {
                                        try {
                                          await EasyLoading.show(
                                              status: null);
                                          await AuthController.updatePass(
                                              newPass: password);
                                          await EasyLoading.dismiss();
                                          Urls.errorMessage == 'no'
                                              ? Navigator.pushAndRemoveUntil(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                  // DriverMap(
                                                  //   token: widget.token,
                                                  //   role: 'driver',
                                                  // )
                                                  DriverVerificationSuccess()
                                              ),
                                                  (route) => false)
                                              : errorWhileOperation(
                                              errorMessage:
                                              "من فضلك تأكد من المعلومات التي ادخلتها",
                                              context: context,
                                              buttonText: 'اعد المحاولة',
                                              func: () {
                                                Navigator.pop(context);
                                              });
                                        } catch (e) {
                                          print(e);
                                        }
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ))
                // Stack(
                //   fit: StackFit.expand,
                //   alignment: AlignmentDirectional.bottomCenter,
                //   children: [
                //     Text(
                //       "tdfd",
                //       style: TextStyle(color: Colors.white, fontSize: 40,backgroundColor: Colors.black),
                //     )
                //   ],
                // )
              ]))),
    );
  }
}
