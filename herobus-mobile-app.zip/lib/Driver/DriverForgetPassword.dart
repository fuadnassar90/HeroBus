import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../Resources/LayoutController.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import '../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/CustomWidgets/CustomArrowBack.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/CustomWidgets/CustomTextField.dart';
import 'package:herobus/Driver/DriverCheck4Digit.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:sizer/sizer.dart';

class DriverForgetPassword extends StatefulWidget {
  DriverForgetPassword({@required this.phoneNumber});

  final String phoneNumber;

  @override
  _DriverForgetPasswordState createState() => _DriverForgetPasswordState();
}

class _DriverForgetPasswordState extends State<DriverForgetPassword> {
  String phone;
  var _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    super.dispose();
    _formKey.currentState?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print(MediaQuery.of(context).size.height);
    return Scaffold(
        body: Form(
            key: _formKey,
            child: Stack(fit: StackFit.expand, children: <Widget>[
              cache.backgroundContainer,
              Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  // mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      child: Container(
                        child: Image(
                          image: AssetImage('assets/images/ic_logo_500.png'),
                          width: 30.w,
                          fit: BoxFit.fill,
                        ),
                      ),
                      padding: EdgeInsets.fromLTRB(0, 40, 20, 0),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(20, 30, 0, 0),
                      child: Text(
                        'إستعاده كلمة المرور',
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: R.strings.fontName,
                            fontSize: 20.sp,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(20, 15.0, 20, 0),
                      child: Text(
                        'يرجي ادخال رقم الهاتف للمتابعة',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                            color: Colors.white,
                            fontFamily: R.strings.fontName,
                            fontSize: 20.sp,
                            fontWeight: FontWeight.w300),
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                  width: MediaQuery.of(context).size.width,
                  bottom: 0,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(0, 50, 0, 0),
                    decoration: BoxDecoration(
                        color: R.colors.whiteMainColor,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(25),
                            topRight: Radius.circular(25))),
                    width: MediaQuery.of(context).size.width,
                    child: SingleChildScrollView(
                      child: Column(
                        children: <Widget>[
                          Container(
                              margin: EdgeInsets.fromLTRB(20, 30, 20, 0),
                              child: CustomTextField(
                                initText: widget.phoneNumber,
                                max: 9,
                                // suffix: Text('962+  '),

                                suffix: RichText(
                                  text: TextSpan(
                                    style: Theme.of(context).textTheme.body1,
                                    children: [
                                      TextSpan(
                                          text: '  962+ ',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold)),
                                      WidgetSpan(
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 2.0),
                                          child: Image(
                                            image: AssetImage(
                                                'assets/images/jordan_logo.png'),
                                            width: 16,
                                            height: 16,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                      TextSpan(text: ''),
                                    ],
                                  ),
                                ),
                                suffixStyle: TextStyle(),
                                onChange: (String val) {
                                  phone = val;
                                },
                                validator: (String val) {
                                  if (val.isEmpty)
                                    return 'هذا العنصر يجب ان لا يبقى فارغاً';
                                  return null;
                                },
                                hintText: "رقم الهاتف",
                                topHintText: "ادخل رقم الهاتف   ",
                                textAlign: TextAlign.right,
                                keyboardType: TextInputType.number,
                              )),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                            child: Padding(
                              padding:
                                  const EdgeInsets.fromLTRB(0, 18.0, 0, 30),
                              child: ButtonTheme(
                                height: 7.h,
                                minWidth:
                                    MediaQuery.of(context).size.width - 40,
                                child: CustomRaisedButton(
                                  text: "المتابعة",
                                  color: R.colors
                                      .splashScreenViewPagerSelectedIndicatorColor,
                                  onPressed: () async {
                                    if (_formKey.currentState.validate()) {
                                      try {
                                        await EasyLoading.show(status: null);
                                        await AuthController.forgetPassword(
                                            phone: phone);
                                        await EasyLoading.dismiss();
                                        Urls.errorMessage == 'no'
                                            ? Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        DriverCheck4Digit(
                                                          phoneNumber:
                                                              AuthController
                                                                  .formatPhone(
                                                                      phone),
                                                        )),
                                              )
                                            : errorWhileOperation(
                                                errorMessage:
                                                    "من فضلك تأكد من المعلومات التي ادخلتها",
                                                context: context,
                                                buttonText: 'اعد المحاولة',
                                                func: () {
                                                  Navigator.pop(context);
                                                });
                                      } catch (e) {
                                        print(e);
                                      }
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () async {
                              String url = 'https://wa.me/+962785755223';
                              await canLaunch(url)
                                  ? await launch(url)
                                  : throw 'Could not launch $url'; // change to -> DriverRegistry()
                            },
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    "تواصل معنا",
                                    style: TextStyle(
                                        color: R.colors
                                            .splashScreenViewPagerSelectedIndicatorColor,
                                        fontFamily: R.strings.fontName,
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w400),
                                  ),
                                  Text(
                                    "هل تواجه مشكلة ؟ ",
                                    style: TextStyle(
                                        color: R.colors.textHintColor,
                                        fontFamily: R.strings.fontName,
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w400),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )),
              CustomArrowBack()
              // Stack(
              //   fit: StackFit.expand,
              //   alignment: AlignmentDirectional.bottomCenter,
              //   children: [
              //     Text(
              //       "tdfd",
              //       style: TextStyle(color: Colors.white, fontSize: 40,backgroundColor: Colors.black),
              //     )
              //   ],
              // )
            ])));
  }
}
