import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class CustomCell extends StatefulWidget {
  CustomCell(this.model);
  final model;

  @override
  _CustomCellState createState() => _CustomCellState(model);
}

class _CustomCellState extends State<CustomCell> {
  _CustomCellState(this.model);
  final model;

  @override
  Widget build(BuildContext context) {
    return getWidget(model);
  }

  Widget getWidget(model) {
    // return Container(
    //   margin: EdgeInsets.fromLTRB(10, 10, 10, 20),
    //   height: 80,
    //   padding: EdgeInsets.symmetric(horizontal: 6),
    //   decoration: BoxDecoration(
    //       color: Colors.white,
    //       border: Border.all(color: Colors.black, width: 1.0),
    //       borderRadius: BorderRadius.circular(20)),
    //   child: Row(
    //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //     crossAxisAlignment: CrossAxisAlignment.center,
    //     children: <Widget>[
    //       Padding(
    //         padding: const EdgeInsets.only(left: 8.0),
    //         child: Icon(
    //           Icons.arrow_back_ios,
    //           color: Colors.black,
    //         ),
    //       ),
    //       Row(
    //         children: <Widget>[
    //           Column(
    //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //             crossAxisAlignment: CrossAxisAlignment.start,
    //             children: <Widget>[
    //               Container(
    //                   margin: EdgeInsets.fromLTRB(20, 10, 0, 0),
    //                   child: Text(model['name'])),
    //               Container(
    //                 margin: EdgeInsets.fromLTRB(0, 0, 0, 15),
    //                 child: Text(
    //                     '${model['current_work_buses']} : الحافلات النشطة حاليا ً'),
    //               ),
    //             ],
    //           ),
    //           VerticalDivider(
    //             color: Colors.black,
    //             thickness: 1,
    //           ),
    //           Container(
    //             margin: EdgeInsets.fromLTRB(0, 10, 10, 10),
    //             child: Image(
    //               image: AssetImage('assets/images/bus.png'),
    //               fit: BoxFit.cover,
    //             ),
    //           ),
    //         ],
    //       ),
    //     ],
    //   ),
    // );
    print('model[name]='+model['name']);
    return Padding(
      padding: EdgeInsets.only(top: 8),
      child: Card(
        margin: EdgeInsets.fromLTRB(20, 6, 20, 0),
        child: ListTile(
          contentPadding: EdgeInsets.symmetric(horizontal: 6, vertical: 15.0),
          trailing: Container(
            padding: EdgeInsets.only(right: 12.0),
            decoration: new BoxDecoration(
                border: new Border(
                    left:
                        new BorderSide(width: 2.0, color: Colors.blueAccent))),
            child: Icon(
              Icons.directions_bus,
              color: Colors.blueAccent,
              size: 45,
            ),
          ),
          title: Text(
            model['name'],
            style:
                TextStyle(color: Colors.black54, fontWeight: FontWeight.bold),
            textAlign: TextAlign.end,
          ),
          // subtitle: Text("Intermediate", style: TextStyle(color: Colors.white)),

          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text('${model['current_work_buses']} : الحافلات النشطة حاليا ً',
                  style: TextStyle(color: Colors.black54)),
            ],
          ),
          leading: Icon(Icons.keyboard_arrow_left,
              color: Colors.black45, size: 60.0),
        ),
      ),
    );
  }
}
