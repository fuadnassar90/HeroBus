import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:herobus/Blocks/UpdateOtpBloc.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';

class CustomOtpTextField extends StatefulWidget {
  CustomOtpTextField({this.counterBloc});
  final UpdateOtpBloc counterBloc;

  @override
  _CustomOtpTextFieldState createState() =>
      _CustomOtpTextFieldState(counterBloc: counterBloc);
}

class _CustomOtpTextFieldState extends State<CustomOtpTextField> {
  _CustomOtpTextFieldState({this.counterBloc});

  final UpdateOtpBloc counterBloc;
  String otp = "";
  Widget getOneCell({String string}) {
    return Container(
      width: 10.w,
      height: 5.h,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Text(
            string ?? "•",
            style: TextStyle(
                color: R.colors.whiteMainColor,
                fontFamily: R.strings.fontName,
                fontSize: 10.sp,
                fontWeight: FontWeight.w500),
          ),
          Container(
            width: 30,
            height: 2,
            color: Colors.white,
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(

      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        BlocBuilder(
          bloc: counterBloc,
          builder: (context, List<String> str) {
            return getOneCell(string: str[0]);
          },
          buildWhen: (previousState, state) {
            print(previousState[0] + " " + state[0]);
            if (previousState[0] != state[0]) {
              return false;
            }
            return true;
          },
        ),
        BlocBuilder(
          bloc: counterBloc,
          builder: (context, List<String> str) {
            return getOneCell(string: str[1]);
          },
        ),
        BlocBuilder(
          bloc: counterBloc,
          builder: (context, List<String> str) {
            return getOneCell(string: str[2]);
          },
        ),
        BlocBuilder(
          bloc: counterBloc,
          builder: (context, List<String> str) {
            return getOneCell(string: str[3]);
          },
        ),
      ],
    );
  }
}
