import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:herobus/Resources/Resources.dart';

class CustomTextField extends StatelessWidget {
  final String hintText, topHintText, preText, initText;
  final Function validator;
  final Function onChange;
  final int max;
  final TextAlign textAlign;
  final Widget suffix;
  final Widget prefix;
  final bool readOnly;
  final TextInputType keyboardType;
  final TextStyle suffixStyle, prefixStyle, hintStyle;
 runV(){
 validator();
}
  CustomTextField(
      {this.hintText,
      this.topHintText,
      @required this.validator,
      @required this.onChange,
      this.preText,
      this.max,
      this.textAlign = TextAlign.right,
      this.suffix,
      this.readOnly = false,
      this.keyboardType,
      this.prefix,
      this.prefixStyle,
      this.suffixStyle,
      this.hintStyle,
      this.initText});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          shape: BoxShape.rectangle,
          color: R.colors.textBackgroundColor),
      child: Padding(
        padding: EdgeInsets.fromLTRB(20, 4, 20, 0),
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: TextFormField(
            initialValue: initText,
            validator: validator,
            onChanged: onChange,
            textAlign: textAlign,
            textDirection: TextDirection.rtl,
            readOnly: readOnly,
            keyboardType: keyboardType,
            decoration: InputDecoration(
              prefix: prefix,
              suffix: suffix,
              hintStyle: hintStyle,
              prefixStyle: prefixStyle,
              suffixStyle: suffixStyle,
              hintText: hintText,
              prefixText: preText,
              labelText: topHintText,
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              errorBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 1.0),

            ),
          ),
        ),
      ),
    );
  }
}
