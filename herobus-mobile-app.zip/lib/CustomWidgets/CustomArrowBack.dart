import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class CustomArrowBack extends StatefulWidget {
  CustomArrowBack();


  @override
  _CustomArrowBackState createState() => _CustomArrowBackState();
}

class _CustomArrowBackState extends State<CustomArrowBack> {
  _CustomArrowBackState();

  @override
  Widget build(BuildContext context) {
    return getWidget();
  }

  Widget getWidget() {
   return  Positioned(
     top: 0,
     left: 0,
     child: Container(

       padding: const EdgeInsets.only(top: 30,  left: 10),
       child: Container(
         // color: Colors.blueAccent,
         child: IconButton(
           icon: Icon(Icons.arrow_back),
           color: Colors.white,
           onPressed: () {
             Navigator.pop(context);
           },
         ),
       ),
     ),
   );
  }
}
