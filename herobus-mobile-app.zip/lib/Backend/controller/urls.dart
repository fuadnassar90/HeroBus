import 'package:flutter/material.dart';
import 'package:herobus/Backend/Cashe/cache.dart';



mixin Urls {
  //a
  // static const API_URL = "http://192.168.1.102:8080/"; // this laptup
  // static const API_URL = "http://192.168.1.113:8080/"; // toshiba laptop
  static const API_URL = "https://herobus.herokuapp.com/";
  static const API_SOCKET_URL = API_URL;
  static const API_URL_USERS = "${API_URL}app/users/";
  static const API_URL_DRIVERS = "${API_URL}app/drivers/";
  static const API_URL_BUSES = "${API_URL}app/buses/";

  static const initLoginUrl = "${API_URL_USERS}initlogin";
  static const userCheckUpdateURL = "${API_URL_USERS}checkupdate";
  static const initMapUser = "${API_URL_USERS}initmap";
  static const initMapDriver = "${API_URL_DRIVERS}initmap";
  static const initLoginUrlDriver = "${API_URL_DRIVERS}initlogin";
  static const registryDriver = "${API_URL_BUSES}order/add";
  static const autoLoginUrl = "${API_URL_USERS}autologin";
  static const getAllRoutesUrl = "${API_URL_USERS}getallroutes";
  static const autoLoginUrlDriver = "${API_URL_DRIVERS}autologin";
  static const forgetPasswordDriver = "${API_URL_DRIVERS}sms/send";
  static const checkPasswordCodeDriver = "${API_URL_DRIVERS}sms/check";
  // static const updatePasswordCodeDriver = "${API_URL_DRIVERS}sms/updatepass";
  static const updatePasswordDriver = "${API_URL_DRIVERS}updatepass";
  static const logoutUrl = "${API_URL_USERS}delete";
  static const deleteDriver = "${API_URL_DRIVERS}deletedriver/";
  static const addDriver = "${API_URL_DRIVERS}adddriver";
  static Map<String, dynamic> initLoginBody = {'os': '${cache.os}', 'version': '${cache.version}','push_token': 'cdscsdc'};

  static Map<String, dynamic> initLoginBodyDriver(
      {@required String phone, @required String pass}) =>
      {'phone': '$phone', 'pass': '$pass'};

  static Map<String, dynamic> registryBodyDriver(
      {@required String name_route,
        @required String no_plate,
        @required String phone,
        @required String pass,
        @required String push_token}) =>
      {'name_route': '$name_route', 'no_plate': '$no_plate','phone': '$phone', 'pass': '$pass','push_token': '$push_token'};

  static Map<String, dynamic> authHeaders({@required String token}) =>
      {'Authorization': 'bearer $token'};

  static Map<String, dynamic> forgetPasswordBodyDriver(
      {@required String phone}) =>
      {'phone': '$phone'};

  static Map<String, dynamic> checkCodeBodyDriver(
      {@required String phone,
        @required String code,
        @required String hash}) =>
      {'phone': '$phone', 'code': '$code', 'hash': '$hash'};

  static String errorMessage;
  static String hashSMS;
  static List<dynamic> routeList = [];
}
