import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:herobus/Backend/Cashe/driverCache.dart';
import 'package:herobus/Backend/Cashe/preferances.dart';
import 'package:herobus/Backend/Cashe/userCache.dart';
import 'package:herobus/Backend/controller/urls.dart';

class AuthController {
  static Future initUserLogin() async {
    Dio dio = new Dio();
    await dio
        .post(Urls.initLoginUrl,
            data: Urls.initLoginBody,
            options: Options(
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('run true and value is=' + value.toString());
      } else {
        DataInLocal.saveInLocal(token: value.toString(), role: 'user', id: '0');
        // autoLoginDriver(token: value.toString());
        Urls.errorMessage = 'no';
        cache.token = value.toString();
        cache.role = 'user';
      }
    }).catchError((error) {
      print(error);
    });
  }

  static Future initLoginDriver(
      {@required String phone, @required String pass}) async {
    phone = await formatPhone(phone);
    pass = await formatArabicNumber(pass);
    Dio dio = new Dio();
    await dio
        .post(Urls.initLoginUrlDriver,
            data: Urls.initLoginBodyDriver(phone: phone, pass: pass),
            options: Options(
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      print('run then method\n$value');
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('response error' + value.toString());
      } else {
        var listvalue = value.toString().split(":");
        print(listvalue);
        driverCache.id_driver = listvalue[0];
        DataInLocal.saveInLocal(
            token: listvalue[1], role: 'driver', id: listvalue[0]);
        print('------------------------- driverCache.id_driver:' +
            driverCache.id_driver);
        Urls.errorMessage = 'no';
        cache.token = value.toString();
        cache.role = 'driver';
      }
    }).catchError((error) {
      print('run catchError in initLoginDriver');
    });
  }

  static Future registryDriver(
      {@required String name_route,
      @required String no_plate,
      @required String phone,
      @required String pass}) async {
    phone = await formatPhone(phone);
    pass = await formatArabicNumber(pass);
    no_plate = await formatArabicNumber(no_plate);
    Response response;
    Dio dio = new Dio();
    await dio
        .post(Urls.registryDriver,
            data: Urls.registryBodyDriver(
                name_route: name_route,
                no_plate: no_plate,
                phone: phone,
                pass: pass,
                push_token: 'ccccc'),
            options: Options(
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      print('run then method\n$value');
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('run true and value is=' + value.toString());
      } else {
        DataInLocal.saveInLocal(token: value.toString(), role: 'driver');
        autoLoginDriver();
        Urls.errorMessage = 'no';
        cache.token = value.toString();
        cache.role = 'driver';
      }
    }).catchError((error) {
      print('run catchError method');
    });
  }

  static Future autoLogin() async {
    Response response;
    Dio dio = new Dio();

    await dio
        .post(Urls.autoLoginUrl,
            data: {'os': '${cache.os}', 'version': '${cache.version}'},
            options: Options(
              headers: Urls.authHeaders(token: cache.token),
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      print(value.toString());
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('run true and value is=' + value.toString());
      } else {
        Urls.errorMessage = 'no';
        // AuthMessages.autoMessageFunc(response);
      }
    }).catchError((error) {
      Urls.errorMessage = 'الخطأ: يوجد مشكلة في بيانات الحساب';
      print('autoLogin method run catchError method....');
      print(error);
    });
  }

  static Future autoLoginDriver() async {
    Dio dio = new Dio();
    await dio
        .post(Urls.autoLoginUrlDriver,
            data: {'os': '${cache.os}', 'version': '${cache.version}'},
            options: Options(
              headers: Urls.authHeaders(token: cache.token),
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) async {
      // print(value.toString());
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('run true and value is=' + value.toString());
      } else {
        // print(value.data['route']);
        dynamic route = value.data['route'];
        dynamic bus = value.data['bus'];
        dynamic drivers = value.data['drivers'] as List;
        driverCache.drivers = drivers;
        driverCache.drivers_length = drivers.length;
        dynamic route_coord = route['coord'].toString();
        dynamic route_zoom = route['zoom'].toString();
        dynamic route_bearing = route['bearing'].toString();
        dynamic route_tilt = route['tilt'].toString();
        String route_path = route['path'].toString();
        driverCache.map_init_coord = route_coord;
        driverCache.map_init_zoom = route_zoom;
        driverCache.map_init_bearing = route_bearing;
        driverCache.map_init_tilt = route_tilt;
        driverCache.map_init_path = route_path.split('-');
        dynamic bus_id_route = bus['id_route'].toString();
        driverCache.id_route = bus_id_route;
        Urls.errorMessage = 'no';
      }
    }).catchError((error) {
      Urls.errorMessage = 'الخطأ: يوجد مشكلة في بيانات الحساب';
      print('run catchError method....');
    });
  }

  static Future deleteDriver({@required String id}) async {
    Response response;
    Dio dio = new Dio();

    await dio
        .delete(Urls.deleteDriver + id,
            options: Options(headers: Urls.authHeaders(token: cache.token)))
        .then((value) {
      print('run then method\n$value');
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('run true and value is=' + value.toString());
      } else {
        // DataInLocal.saveInLocal(token: value.toString(), role: 'driver');
        // autoLoginDriver(token: value.toString());
        Urls.errorMessage = 'no';
        // cache.token = value.toString();
      }
    }).catchError((error) {
      Urls.errorMessage = 'الخطأ: لا يمكنك حذف حسابك';
      print('run catchError method');
    });
  }

  static Future addDriver(
      {@required String phone, @required String pass}) async {
    Response response;
    Dio dio = new Dio();
    phone = await formatPhone(phone);
    pass = await formatArabicNumber(pass);
    await dio
        .post(Urls.addDriver,
            data: Urls.initLoginBodyDriver(phone: phone, pass: pass),
            options: Options(
              headers: Urls.authHeaders(token: cache.token),
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      print('run then method\n$value');
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('run true and value is=' + value.toString());
      } else {
        print(value.data[0]);
        driverCache.drivers.add(value.data[0]);
        Urls.errorMessage = 'no';
      }
    }).catchError((error) {
      Urls.errorMessage = 'الخطأ: لا يمكنك اضافة هذا الحساب';
      print('run catchError method');
    });
  }

  static Future logout() async {
    Response response;
    Dio dio = new Dio();
    try {
      response = await dio.delete(Urls.logoutUrl,
          options: Options(headers: Urls.authHeaders(token: cache.token)));
    } catch (e) {
      print('$e in logout');
    }
  }

  static Future forgetPassword({@required String phone}) async {
    phone = await formatPhone(phone);
    Response response;
    Dio dio = new Dio();
    await dio
        .post(Urls.forgetPasswordDriver,
            data: Urls.forgetPasswordBodyDriver(phone: phone),
            options: Options(
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      print('run then method\n$value');
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('run true and value is=' + value.toString());
      } else {
        Urls.errorMessage = 'no';
        Urls.hashSMS = value.toString();
      }
    }).catchError((error) {
      print('run catchError method');
      print(error);
    });
  }

  static Future checkCode(
      {@required String phone,
      @required String code,
      @required String hash}) async {
    Response response;
    Dio dio = new Dio();
    // try {
    //   response = await dio.post(Urls.checkPasswordCodeDriver,
    //       data: Urls.checkCodeBodyDriver(phone: phone, code: code, hash: hash),
    //       options: Options(contentType: Headers.formUrlEncodedContentType));
    //   AuthMessages.messageFunc(response, 'driver');
    // } catch (e) {
    //   print('$e in check code method');
    // }
    await dio
        .post(Urls.checkPasswordCodeDriver,
            data:
                Urls.checkCodeBodyDriver(phone: phone, code: code, hash: hash),
            options: Options(
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      print('run then in checkCode method\n$value');
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('run true and value is=' + value.toString());
      } else {
        Urls.errorMessage = 'no';
        Urls.hashSMS = value.toString();
        cache.token=value.toString();
      }
    }).catchError((error) {
      print('run catchError method');
    });
  }

  // static Future updatePass(
  //     {@required String newPass}) async {
  //   Response response;
  //   Dio dio = new Dio();
  //   newPass = formatArabicNumber(newPass);
  //   try {
  //     response = await dio.post(Urls.updatePasswordCodeDriver,
  //         data: Urls.updatePasswordBodyDriver(pass: newPass),
  //         options: Options(
  //             contentType: Headers.formUrlEncodedContentType,
  //             headers: Urls.authHeaders(token: cache.token)));
  //
  //   } catch (e) {
  //     print('$e in update pass method');
  //   }
  // }
  static Future updatePass({@required String newPass}) async {
    Dio dio = new Dio();
    newPass = formatArabicNumber(newPass);
    print('cache.token: ${cache.token}');
    await dio
        .post(Urls.updatePasswordDriver,
            data: {'new_pass': '$newPass'},
            options: Options(
              contentType: Headers.formUrlEncodedContentType,
              headers: Urls.authHeaders(token:cache.token),
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
          print('-------------------------------');
          print(value);
          print('-------------------------------');
      if (value.toString().contains('خطأ')) {
        Urls.errorMessage = value.toString();
        print('error in updatePass' + value.toString());
      } else {
        var listvalue = value.toString().split(":");
        print(listvalue);
        driverCache.id_driver = listvalue[0];
        DataInLocal.saveInLocal(
            token: listvalue[1], role: 'driver', id: listvalue[0]);
        print('------------------------- driverCache.id_driver:' +
            driverCache.id_driver);
        Urls.errorMessage = 'no';
        cache.token = value.toString();
        cache.role = 'driver';
      }
    }).catchError((error) {
      Urls.errorMessage = 'الخطأ: يوجد مشكلة في كلمة السر';
      print('run catchError method in updatePass');
    });
  }

  static Future initMapUser({@required String id_route}) async {
    Dio dio = new Dio();
    await dio
        .post(Urls.initMapUser,
            data: {'id_route': '$id_route'},
            options: Options(
              headers: Urls.authHeaders(token: cache.token),
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      dynamic user = value.data['user'];
      dynamic route = value.data['route'][0];
      dynamic buses_temp_info = value.data['buses_temp_info'] as List;
      userCache.id_user = user['id_user'].toString();
      userCache.id_route = route['id'].toString();
      userCache.map_init_coord = route['coord'].toString();
      userCache.map_init_zoom = route['zoom'].toString();
      userCache.map_init_bearing = route['bearing'].toString();
      userCache.map_init_tilt = route['tilt'].toString();
      userCache.map_init_path = route['path'].split('-');
      userCache.buses_temp_info = buses_temp_info;
      // print('${userCache.id_route}  -  ${userCache.map_init_coord}  -  ${userCache.map_init_zoom}  -  ${userCache.map_init_bearing}  -  ${userCache.map_init_tilt}  ');
    }).catchError((error) {
      Urls.errorMessage = 'الخطأ: يوجد مشكلة في بيانات خط الحافلة';
      print('run catchError method....');
    });
  }

  static Future initMapDriver({@required String id_route}) async {
    print('run initMapDriver $id_route');
    Dio dio = new Dio();
    await dio
        .post(Urls.initMapDriver,
            data: {'id_route': '$id_route'},
            options: Options(
              headers: Urls.authHeaders(token: cache.token),
              contentType: Headers.formUrlEncodedContentType,
              followRedirects: false,
              validateStatus: (status) {
                return status < 500;
              },
            ))
        .then((value) {
      print('run initMapDriver then');
      dynamic buses_temp_info = value.data['buses_temp_info'] as List;
      dynamic users_temp_info = value.data['users_temp_info'] as List;
      userCache.buses_temp_info = buses_temp_info;
      userCache.users_temp_info = users_temp_info;
    }).catchError((error) {
      Urls.errorMessage = 'الخطأ: يوجد مشكلة في بيانات خط الحافلة';
      print('run catchError method....');
    }).whenComplete(() => print('run initMapDriver whenComplete1'));
  }

  static String formatPhone(String phone) {
    phone = phone
        .replaceAll(' ', '')
        .replaceAll('٠', '0')
        .replaceAll('١', '1')
        .replaceAll('٢', '2')
        .replaceAll('٣', '3')
        .replaceAll('٤', '4')
        .replaceAll('٥', '5')
        .replaceAll('٦', '6')
        .replaceAll('٧', '7')
        .replaceAll('٨', '8')
        .replaceAll('٩', '9')
        .replaceAll('+', '');

    if (phone.startsWith('962')) {
      phone = phone.replaceFirst('962', '+962');
    } else if (phone.startsWith('00962')) {
      phone = phone.replaceFirst('00962', '+962');
    } else if (phone.startsWith('0')) {
      phone = phone.replaceFirst('0', '+962');
    } else {
      phone = '+962$phone';
    }
    print('phone affter format:$phone');
    return phone;
  }

  static String formatArabicNumber(String pass) {
    pass = pass
        .replaceAll('٠', '0')
        .replaceAll('١', '1')
        .replaceAll('٢', '2')
        .replaceAll('٣', '3')
        .replaceAll('٤', '4')
        .replaceAll('٥', '5')
        .replaceAll('٦', '6')
        .replaceAll('٧', '7')
        .replaceAll('٨', '8')
        .replaceAll('٩', '9');
    print('pass affter format:$pass');
    return pass;
  }
}
