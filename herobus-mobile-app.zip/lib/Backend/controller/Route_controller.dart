
import 'package:herobus/Backend/controller/urls.dart';
import 'package:dio/dio.dart';

class RoutingController {
  // static List<AllRoutesModel> _allRoutesModel = <AllRoutesModel>[];
  // static List<AllRoutesModel> get allRoutesModel => _allRoutesModel;

  static Future getAllRoutes() async {
    Response response;
    Dio dio = new Dio();
    try {
      response = await dio.get(Urls.getAllRoutesUrl);

      messageFunc(response);
    } catch (e) {
      print('$e in logout');
    }
  }

  static messageFunc(Response response) async {
    switch (response.statusCode) {
      case 200:
        {
          //Response type is a list of dynamic not a json type
          Urls.routeList = response.data;
          Urls.errorMessage = 'no';
          print(response.statusCode);
        }
        break;
      case 201:
        {
          Urls.routeList = response.data;
          Urls.errorMessage = 'no';
          print(response.statusCode);
        }
        break;
      case 400:
        {
          Urls.errorMessage = 'You sent something wrong';
          print(response.statusCode);
        }
        break;
      case 401:
        {
          Urls.errorMessage = 'Invalid Email or Password';
          print(response.statusCode);
        }
        break;
      case 404:
        {
          Urls.errorMessage = 'You did something NOT FOUND !';
          print(response.statusCode);
        }
        break;
      case 500:
        {
          Urls.errorMessage =
              'Server Error : we have a problem just try again later';
          print(response.statusCode);
        }
        break;
      default:
        {
          Urls.errorMessage =
              'We have Unknown error just connect us later or feedback ${response.statusCode}';
          print(response.statusCode);
        }
    }
  }
}
