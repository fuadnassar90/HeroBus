import 'package:flutter/material.dart';
import 'package:herobus/Backend/Cashe/driverCache.dart';
import '../controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import '../../Driver/Map/DriverMap.dart';
import 'package:herobus/Driver/DriverPending.dart';
import 'package:herobus/User/UserSelectRoute.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:herobus/dialogs/update.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:herobus/Backend/Cashe/cache.dart';

class DataInLocal {
  static Future<void> saveInLocal(
      {@required String token, @required String role, @required String id}) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String key = 'token';
    final String value = token;
    final String roleKey = 'role';
    final String roleValue = role;
    final String idkey = 'id';
    final String idvalue = id;
    prefs.setString(key, value);
    prefs.setString(roleKey, roleValue);
    prefs.setString(idkey, idvalue);
    print('value was stored');
  }

  static Future<void> save(
      {@required String key, @required String value}) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String keys = key;
    final String values = value;
    prefs.setString(keys, values);
    print('value was stored');
  }

  static Future<dynamic> get(String key) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String keyOnLocal = key;
    final dynamic value = prefs.get(keyOnLocal) ?? '0';
    print('reading from local , $key is : $value ');
    return value;
  }

  static Future<String> readTokenFromLocal() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String key = 'token';
    final String value = prefs.get(key) ?? '0';
    print('reading from local , token is : $value ');
    return value;
  }

  static Future<dynamic> readValueFromLocal(String key) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String keyOnLocal = key;
    final dynamic value = prefs.get(keyOnLocal) ?? '0';
    print('reading from local , $key is : $value ');
    return value;
  }

  static Future<void> useValueToNavigate(BuildContext context) async {
    print('run1');
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String key = 'token';
    final String value = prefs.get(key) ?? '0';
    final String roleKey = 'role';
    final String roleValue = prefs.get(roleKey) ?? '0';
    final String idKey = 'id';
    final String idValue = prefs.get(idKey) ?? '0';
    print('value: ' + value);
    print('roleValue: ' + roleValue);
    print('idValue: ' + idValue);
    if (value != '0' && roleValue != '0' && value != '' && roleValue != '') {
      //call auto login then nav
      // print('role is:$roleValue');
      cache.token = value;
      cache.role = roleValue;

      driverCache.id_driver = roleValue=='driver'?idValue:'0';

      roleValue == 'user'
          ? await AuthController.autoLogin()
          : await AuthController.autoLoginDriver();

      if (Urls.errorMessage == 'no') {
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => roleValue == 'driver'
                  ? DriverMap()
                  : UserSelectRoute(),
            ),
                (route) => false);
      } else {
        if (Urls.errorMessage.contains('تحديث')) {
          print('يتوجب تحديييييييث ' + Urls.errorMessage);
          updateOperation(
              context: context,
              func: () {
                Navigator.pop(context);
              });
        } else if (Urls.errorMessage.contains('غير مفعل')) {
          Navigator.push(
              context, MaterialPageRoute(builder: (c) => DriverPending()));
        }
      }
    } else {
      //nothing
      print('no token in database');
    }
  }
}
