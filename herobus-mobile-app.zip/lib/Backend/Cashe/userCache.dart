import 'package:flutter/material.dart';
import 'package:herobus/Backend/controller/urls.dart';

mixin userCache {
  static String id_user = "";
  static const initLoginUrl = "${Urls.API_URL_USERS}initlogin";
  static String id_route = "";
  static String map_init_coord = "";
  static String map_init_zoom = "";
  static String map_init_bearing = "";
  static String map_init_tilt = "";
  static List map_init_path = [];
  static List buses_temp_info = [];
  static List users_temp_info = [];
}
