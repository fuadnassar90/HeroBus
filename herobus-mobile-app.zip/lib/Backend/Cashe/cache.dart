
import 'dart:io';

import 'package:flutter/material.dart';


mixin cache {
  static String token;
  static String role;
  static String os=Platform.isAndroid?'android':'ios';
  static String version=Platform.isAndroid?'0.0.1':'0.0.1';
  static String storeURL=Platform.isAndroid?'https://play.google.com/store/apps/details?id=com.cafjo.herobus':'https://apps.apple.com/';  /// ----------------------- shoud update apple store url after first release
  static BuildContext currentContext;
  static String push_token;

  // static AssetImage backgroundAssetImage;
  static Container backgroundContainer;

  // static AssetImage welcomeAssetImage;

  // static Image busImage;

}
