import 'package:flutter/material.dart';
mixin driverCache {
  // Driver
  static String id_driver = "";
  static String map_init_coord = "";
  static String map_init_zoom = "";
  static String map_init_bearing = "";
  static String map_init_tilt = "";
  static List map_init_path = [];
  static List drivers = [];
  static int drivers_length = 0;

  //Bus
  static String id_route = "";
}
