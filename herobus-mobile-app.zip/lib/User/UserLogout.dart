import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../Resources/LayoutController.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import '../Backend/controller/AutheticationController.dart';

import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/LoginAs.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:sizer/sizer.dart';

class UserLogout extends StatefulWidget {

  UserLogout();
  @override
  _UserLogoutState createState() => _UserLogoutState();
}

class _UserLogoutState extends State<UserLogout> {
  String phone;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: <Widget>[
        cache.backgroundContainer,
        SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: LayoutController.getHeight(
                (MediaQuery.of(context).size.height - 60),
                minHeight: 740),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.fromLTRB(0, 50, 0, 0),
                  decoration: BoxDecoration(
                      color: R.colors.whiteMainColor,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(25),
                          topRight: Radius.circular(25))),
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * .5,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Image.asset(
                            'assets/images/facebook.png',
                            width: 10.w,
                            height: 10.h,
                          ),
                          Image.asset('assets/images/whatsapp.png',
                              width: 50, height: 50),
                          Image.asset('assets/images/youtube.png',
                              width: 50, height: 50),
                        ],
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(0, 18.0, 0, 30),
                          child: ButtonTheme(
                            height: 7.h,
                            minWidth: MediaQuery.of(context).size.width - 40,
                            child: CustomRaisedButton(
                              text: "تسجيل الخروج",
                              borderColor: R.colors
                                  .splashScreenViewPagerSelectedIndicatorColor,
                              textColor: R.colors
                                  .splashScreenViewPagerSelectedIndicatorColor,
                              color: Colors.white,
                              onPressed: () async {
                                await EasyLoading.show(status: 'Logging out..');
                                await AuthController.logout();
                                await EasyLoading.dismiss();
                                Urls.errorMessage == 'no'
                                    ? Navigator.pushAndRemoveUntil(
                                        context,
                                        MaterialPageRoute(
                                            builder: (c) => LoginAs()),
                                        (route) => false)
                                    : errorWhileOperation(
                                        errorMessage: Urls.errorMessage,
                                        context: context,
                                        buttonText: 'Try Again',
                                        func: () {
                                          Navigator.pop(context);
                                        });
                              },
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        )
      ],
    ));
  }
}
