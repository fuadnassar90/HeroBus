import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:herobus/Backend/Cashe/userCache.dart';
import 'dart:ui' as ui;

import 'package:herobus/Resources/Resources.dart';
class userMapCache{


  static double _lat, _lng, _zoom, _bearing, _tilt,_driverLat, _driverLng, _driverHead = 0;
  static List<LatLng> _coords = [];

  static void loadData(){
    _lat = double.parse(userCache.map_init_coord.split(',')[0].toString());
    _lng = double.parse(userCache.map_init_coord.split(',')[1].toString());
    _zoom = double.parse(userCache.map_init_zoom.toString());
    _bearing = double.parse(userCache.map_init_bearing.toString());
    _tilt = double.parse(userCache.map_init_tilt.toString());
    // print('''$lat+'  :   '+$lng+'  :     '+$zoom+'  :   '+$bearing+'  :   '+$tilt+'  :   ''');
    List route = userCache.map_init_path;
    for (String coord in route) {
      var split = coord.split(',');
      double lat = double.parse(split[0]);
      double lng = double.parse(split[1]);
      _coords.add(LatLng(lat, lng));
    }

  }
  static CameraPosition getInitCamera(){
     final CameraPosition _kGooglePlex = CameraPosition(
        target: LatLng(_lat, _lng), zoom: _zoom, bearing: _bearing, tilt: _tilt);
    return _kGooglePlex;
  }

  static Set<Polyline> getPathPolyline(){
    Set<Polyline> polylineSet = {};
    Polyline polyline = Polyline(
        polylineId: PolylineId('1'),
        points: _coords,
        color: Colors.blueAccent,
        jointType: JointType.round,
        width: 5,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
        geodesic: true);
    polylineSet.add(polyline);
    return polylineSet;
  }
  static Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
        targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))
        .buffer
        .asUint8List();
  }

  static pprint(data) {
      if (data is Map) {
        data = json.encode(data);
      }
      print(data);
  }

  static Widget getMaximisedWidget() {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.fromLTRB(0, 10, 30, 0),
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(right: 20, top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      "٢ دقائق",
                      style: GoogleFonts.almarai(
                          color: R.colors.homeGreenColor,
                          fontSize: 18,
                          fontWeight: FontWeight.w400),
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text(
                      ' : وقت الوصل ',
                      style: GoogleFonts.almarai(
                          color: Color(0xff474747),
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 0, top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      'متحركة',
                      style: GoogleFonts.almarai(
                          color: R.colors.homeGreenColor,
                          fontSize: 18,
                          fontWeight: FontWeight.w400),
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text(
                      ' : حالة الحافلة ',
                      style: GoogleFonts.almarai(
                          color: Color(0xff474747),
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Widget getMinimisedWidget() {
    return Container(
      height: 30,
    );
  }




}