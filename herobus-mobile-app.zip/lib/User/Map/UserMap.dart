import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:herobus/Backend/Cashe/map_style.dart';
import 'package:herobus/Backend/Cashe/userCache.dart';
import 'package:herobus/Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/Blocks/BottomMenuChooserBloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:herobus/Driver/DriverMenu.dart';
import 'package:herobus/User/Map/userMapCache.dart';
import 'package:herobus/User/UserMenu.dart';
import 'package:location/location.dart';
import 'package:herobus/User/CustomUserMapMaxMinData.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:ui' as ui;
import 'package:permission_handler/permission_handler.dart' as permission;
import 'package:adhara_socket_io/adhara_socket_io.dart';

class UserMap extends StatefulWidget {
  @override
  _UserMapState createState() => _UserMapState();
}

double mapOffset = 105.0;
double myLocationBtnOffset = 280;
// double lat, lng, rotate, zoom, bearing, tilt;
double userLat, userLng;

class _UserMapState extends State<UserMap> {
  SocketIOManager manager;
  SocketIO socket;
  bool _isSocketConnected = false;
  String _mapStyle;
  List buses_temp_info = [];
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  Marker userMarker;
  Completer<GoogleMapController> _controller = Completer();
  StreamSubscription<LocationData> locationSubscription = null;
  final BottomMenuChooserBloc _bottomMenuChooserBloc =
  BottomMenuChooserBloc(BottomMenuChooserBlocEvent.home);
  final _CustomUserMapMaxMinData = CustomUserMapMaxMinData(false);

  List<String> bus = ["الحافلة رقم ١", "الحافلة رقم ٢", "الحافلة رقم 1505"];
  PageController pageController = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
          children: <Widget>[
            SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height - 60,
                color: R.colors.loginButtonColor,
                child: FutureBuilder(
                  future: Future.delayed(Duration(milliseconds: 1000)),
                  builder: (context, snapshot) {
                    return GoogleMap(
                      myLocationButtonEnabled: false,
                      myLocationEnabled: true,
                      zoomControlsEnabled: true,
                      padding: EdgeInsets.only(
                        bottom: mapOffset,
                      ),
                      mapType: MapType.normal,
                      initialCameraPosition: userMapCache.getInitCamera(),
                      markers: Set<Marker>.of(markers.values),
                      onMapCreated: (GoogleMapController controller) {
                        _controller.complete(controller);
                        setMapStyle();
                      },
                      polylines: userMapCache.getPathPolyline(),
                      compassEnabled: false,
                    );
                  },
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  Container(
                    // margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                    decoration: BoxDecoration(
                        color: R.colors.whiteMainColor,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(25),
                            topRight: Radius.circular(25))),
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      children: <Widget>[
                        Padding(
                          // margin: EdgeInsets.fromLTRB(20, 15, 20, 0),
                            padding: EdgeInsets.only(left: 20, top: 20, right: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Container(
                                    height: 40,
                                    child: BlocBuilder(
                                        bloc: _CustomUserMapMaxMinData,
                                        builder: (context, bool i) {
                                          if (!i) {
                                            return GestureDetector(
                                                onTap: () {
                                                  _CustomUserMapMaxMinData.add(
                                                      CustomUserMapMaxMinDataEvent
                                                          .minimise);
                                                  setState(() {
                                                    mapOffset = 25;
                                                    myLocationBtnOffset = 200;
                                                  });
                                                  // print("------------------ is run");
                                                  //_goToTheLake();
                                                },
                                                child: AnimatedSwitcher(
                                                    duration:
                                                    Duration(milliseconds: 500),
                                                    transitionBuilder:
                                                        (Widget child,
                                                        Animation<double>
                                                        animation) {
                                                      return ScaleTransition(
                                                        scale: animation,
                                                        child: child,
                                                      );
                                                    },
                                                    child: Image(
                                                      key: Key("img_1"),
                                                      image: AssetImage(
                                                          'assets/images/fold_down_icon.png'),
                                                      fit: BoxFit.fill,
                                                    )));
                                          } else {
                                            return GestureDetector(
                                                onTap: () {
                                                  _CustomUserMapMaxMinData.add(
                                                      CustomUserMapMaxMinDataEvent
                                                          .maximise);
                                                  setState(() {
                                                    mapOffset = 105;
                                                    myLocationBtnOffset = 280;
                                                  });
                                                },
                                                child: AnimatedSwitcher(
                                                    duration:
                                                    Duration(milliseconds: 500),
                                                    transitionBuilder:
                                                        (Widget child,
                                                        Animation<double>
                                                        animation) {
                                                      return ScaleTransition(
                                                        scale: animation,
                                                        child: child,
                                                      );
                                                    },
                                                    child: Image(
                                                      key: Key("img_2"),
                                                      image: AssetImage(
                                                          'assets/images/fold_up_icon.png'),
                                                      fit: BoxFit.fill,
                                                    )));
                                          }
                                        })),
                                Container(
                                  width: 250,
                                  height: 45,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.black, width: 1)),
                                  child: Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: IconButton(
                                            icon: Icon(Icons.arrow_back_ios),
                                            onPressed: () {
                                              pageController.nextPage(
                                                  duration:
                                                  Duration(microseconds: 200),
                                                  curve: Curves.easeInBack);
                                            }),
                                      ),
                                      Expanded(
                                        child: PageView.builder(
                                          controller: pageController,
                                          scrollDirection: Axis.horizontal,
                                          physics: NeverScrollableScrollPhysics(),
                                          itemBuilder: (c, i) => Center(
                                            child: Text(
                                              bus[i],
                                              style: TextStyle(
                                                color: Color(0xff474747),
                                                fontSize: 16,
                                                fontWeight: FontWeight.w700,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          itemCount: bus.length,
                                        ),
                                      ),
                                      Expanded(
                                        child: IconButton(
                                          icon: Icon(Icons.arrow_forward_ios),
                                          onPressed: () {
                                            pageController.previousPage(
                                                duration:
                                                Duration(microseconds: 200),
                                                curve: Curves.easeInBack);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            )),

                        // Padding(
                        //   padding: const EdgeInsets.only(right: 40, top: 10),
                        //   child: Row(
                        //     mainAxisAlignment: MainAxisAlignment.end,
                        //     children: <Widget>[
                        //       Text(
                        //         "متحركة",
                        //         style: GoogleFonts.almarai(
                        //             color: R.colors.homeRedColor,
                        //             fontSize: 18,
                        //             fontWeight: FontWeight.w400),
                        //       ),
                        //       SizedBox(
                        //         width: 4,
                        //       ),
                        //       Text(
                        //         ': حالة الحافلة',
                        //         style: GoogleFonts.almarai(
                        //             color: Colors.black,
                        //             fontSize: 18,
                        //             fontWeight: FontWeight.w500),
                        //       ),
                        //     ],
                        //   ),
                        // ),
                        BlocBuilder(
                            bloc: _CustomUserMapMaxMinData,
                            builder: (context, bool i) {
                              return AnimatedContainer(
                                  height: (!i) ? 100 : 20,
                                  onEnd: () {},
                                  duration: Duration(milliseconds: 320),
                                  child: (!i)
                                      ? userMapCache.getMaximisedWidget()
                                      : userMapCache.getMinimisedWidget());
                            })
                      ],
                    ),
                  )
                ],
              ),
            ),
            Positioned(
              bottom: myLocationBtnOffset,
              right: 10,
              width: 40,
              height: 40,
              child: FloatingActionButton(
                onPressed: _currentLocation,
                // label: Text(''),

                backgroundColor: Color(0xFFC2C2C2),
                child: Icon(
                  Icons.location_on,
                  color: Color(0xFF000000),
                ),
              ),
            ),
            Positioned(
              right: 0,
              child: Padding(
                padding: const EdgeInsets.only(top: 30, right: 10),
                child: IconButton(
                  icon: Icon(
                    Icons.menu,
                    size: 40,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      CupertinoPageRoute(builder: (c) => UserMenu()),
                    );
                  },
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.only(top: 30, left: 10),
              child: Container(
                // color: Colors.blueAccent,
                child: IconButton(
                  icon: Icon(Icons.arrow_back),
                  color: Colors.white,
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ),
            ),
          ],
        ));
  }

  @override
  void initState() {
    super.initState();
    _mapStyle = map_style.style;
    manager = SocketIOManager();
    userMapCache.loadData();
    connectSocket();
  }

  @override
  void dispose() {
    disconnectSocket();
    super.dispose();
  }

  void setMapStyle() async {
    final GoogleMapController controller = await _controller.future;
    controller.setMapStyle(_mapStyle);
    setState(() {});
  }

  connectSocket() async {
    addPicMarker();
    setState(() => _isSocketConnected = true);
    await _getCurrentLocation();
    if (userLat != null && userLng != null) {
      socket = await manager.createInstance(SocketOptions(Urls.API_SOCKET_URL,
          nameSpace: "/",
          query: {
            "id": userCache.id_user,
            "id_route": userCache.id_route,
            "type": "user",
            "lat": userLat.toString(),
            "lng": userLng.toString(),
            "rotate": "0"
          },
          enableLogging: false,
          transports: [Transports.WEB_SOCKET]));
      socket.onConnect((data) {
        userMapCache.pprint("success connected...");
        // userMapCache.pprint(data);
      });
      socket.onConnectError((data) {
        setState(() => _isSocketConnected = false);
        userMapCache.pprint(data);
      });
      socket.onConnectTimeout((data) {
        setState(() => _isSocketConnected = false);
        userMapCache.pprint(data);
      });
      socket.onError((data) {
        setState(() => _isSocketConnected = false);
        userMapCache.pprint(data);
      });
      socket.onDisconnect((data) {
        setState(() => _isSocketConnected = false);
        userMapCache.pprint(data);
      });
      socket.on("map_drivers", (data) {
        // print(data);

        String action = data['action'].toString();
        switch (action) {
          case 'update':
          case 'add':
            {
              List id_split = data['id'].toString().split('.');
              String socketId = id_split[2];
              double busLat = double.parse(data['lat'].toString());
              double busLng = double.parse(data['lng'].toString());
              double busRotate = double.parse(data['rotate'].toString());

              setState(() {
                addMarker(socketId, busLat, busLng, busRotate);

              });
            }
            break;
          case 'delete':
            {
              List id_split = data['id'].toString().split('.');
              String busId = id_split[1];
              String socketId = id_split[2];
              print('delete socketId: ' + socketId);
              markers.removeWhere((key, value) => key == MarkerId(socketId));
              setState(() {});
            }
            break;
        }
      });
      socket.connect();
      AuthController.initMapUser(id_route: userCache.id_route).whenComplete(() {
        buses_temp_info = userCache.buses_temp_info;
        print('buses_temp_info length:${buses_temp_info.length}');
        buses_temp_info.forEach((element) {
          String socketId = element[0].toString();
          List splitCoord = element[1].toString().split(',');
          String name = splitCoord[0].toString();///...
          double busLat = double.parse(splitCoord[1].toString());
          double busLng = double.parse(splitCoord[2].toString());
          double busRotate = double.parse(splitCoord[3].toString());
          String running = splitCoord[4].toString();///...
          print('add socketId:$socketId');
          addMarker(socketId, busLat, busLng, busRotate);
        });
      });
      setState(() {///.. there's erorr here userMarkerID it is equal null
        addUserMarker();
      });
    } else {
      setState(() => _isSocketConnected = false);
    }
  }

  sendEmitNewLocaion({userLat, userLng}) {
    if (socket != null) {
      socket.emit("map_users", [
        {
          "id": userCache.id_user,
          "id_route": userCache.id_route,
          "type": "user",
          "lat": userLat,
          "lng": userLng,
          "rotate": "0",
        },
      ]);
    }
  }

  disconnectSocket() async {
    print('run disconnectSocket');
    // setState(() {
    _isSocketConnected = false;
    markers.clear();
    if (locationSubscription != null) locationSubscription.cancel();
    // });
    await manager.clearInstance(socket);
  }

  void addMarker(@required String makerID, @required double lat,
      @required double lng, @required double rotate) async {
    final Uint8List markerIcon =
    await userMapCache.getBytesFromAsset('assets/images/ic_bus.png', 120);
    markers[MarkerId(makerID)] = Marker(
      rotation: rotate,
      markerId: MarkerId(makerID),
      position: LatLng(lat, lng),
      icon: BitmapDescriptor.fromBytes(markerIcon),
    );
  } void addPicMarker() async {
    final Uint8List markerIcon =
    await userMapCache.getBytesFromAsset('assets/images/ic_bus.png', 120);
    markers[MarkerId('picmarker')] = Marker(
      // rotation: rotate,
      draggable: true,
      markerId: MarkerId('picmarker'),
      position: LatLng(32.0306098,36.0428955),
      icon: BitmapDescriptor.defaultMarker,
    );
  }

  Widget getMenuItem(String filePath,
      {double width, BottomMenuChooserBlocEvent event}) {
    return GestureDetector(
      onTap: () {
        _bottomMenuChooserBloc.add(event);
      },
      child: Container(
        color: Colors.white,
        child: Padding(
          padding: EdgeInsets.fromLTRB(5, 5, 5, 5),
          child: Container(
              width: width ?? 30,
              child: Image(
                image: AssetImage(filePath),
                fit: BoxFit.fill,
              )),
        ),
      ),
    );
  }

  void _currentLocation() async {
    var location = new Location();
    Map<permission.Permission, permission.PermissionStatus> statuses = await [
      permission.Permission.location,
    ].request();
    print(statuses[permission.Permission.location]);
    if (!await location.serviceEnabled()) {
      location.requestService();
    } else {
      final GoogleMapController controller = await _controller.future;
      LocationData currentLocation;

      try {
        currentLocation = await location.getLocation();
      } on Exception {
        currentLocation = null;
      }

      controller.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
          bearing: 0,
          target: LatLng(currentLocation.latitude, currentLocation.longitude),
          zoom: 17.0,
        ),
      ));
    }
  }

  void addUserMarker() async {
    // BitmapDescriptor bitmapDescriptor = await BitmapDescriptor.fromAssetImage(
    //     ImageConfiguration(size: Size(10, 10)), "assets/images/car.png");

    final Uint8List markerIcon = await userMapCache.getBytesFromAsset(
        'assets/images/ic_persone_location.png', 60);
    markers[MarkerId('usermarkerid')] = Marker(
      markerId: MarkerId('usermarkerid'),
      position: LatLng(userLat, userLng),
      icon: BitmapDescriptor.fromBytes(markerIcon),
    );
  }

  void _getCurrentLocation({bool moveCamera = false}) async {
    var location = new Location();
    Map<permission.Permission, permission.PermissionStatus> statuses = await [
      permission.Permission.location,
    ].request();
    print(statuses[permission.Permission.location]);
    if (!await location.serviceEnabled()) {
      // setState(() {
      //   _isSocketConnected = true;
      // });
      location.requestService().whenComplete(() {
        print('enable gps done');
        connectSocket();
      });
    } else {
      final GoogleMapController controller = await _controller.future;
      LocationData currentLocation;

      try {
        currentLocation = await location.getLocation();
      } on Exception {
        currentLocation = null;
      }
      userLat = currentLocation.latitude;
      userLng = currentLocation.longitude;
      // print('userLat:$userLat userLng:$userLng');
      // if (moveCamera) {
      //   controller.animateCamera(CameraUpdate.newCameraPosition(
      //     CameraPosition(
      //       bearing: 0,
      //       target: LatLng(currentLocation.latitude, currentLocation.longitude),
      //       zoom: 17.0,
      //     ),
      //   ));
      // }
      // if (locationSubscription == null) {
      locationSubscription =
          location.onLocationChanged.listen((LocationData currentLocation) {
            // setState(() {
            userLat = currentLocation.latitude;
            userLng = currentLocation.longitude;
            // markers[MarkerId(busMarkerID)]=busMarker;
            if (_isSocketConnected == true) {
              // print('busMarkerID:$busMarkerID');
              MarkerId id = MarkerId('usermarkerid');
              markers[id] = markers[id].copyWith(
                positionParam: LatLng(userLat, userLng),
                // anchorParam: Offset(0.5, 0.5),
                // draggableParam: false,
                // zIndexParam: 2
              );
            } else {
              print('userMarkerID it is equal null');
            }
            //
            // print(id);
            // markers[id]= markers[id].copyWith(positionParam:LatLng(driverLat,driverLng),rotationParam: driverHead);
            // });
            // print(
            //     'new location driverLat:$driverLat driverLng:$driverLng driverHead:$driverHead ');
            sendEmitNewLocaion(userLat: userLat, userLng: userLng);
          });
      // } else {
      //   locationSubscription.resume();
      // }
    }
  }
}
