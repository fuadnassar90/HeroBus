import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:herobus/Backend/Cashe/preferances.dart';
import 'package:herobus/User/UserSelectRoute.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:sizer/sizer.dart';

class UserTabs extends StatefulWidget {

  UserTabs();
  @override
  _UserTabsState createState()  {
    DataInLocal.save(key: 'userfirstlogin', value: 'false');
    return _UserTabsState();}
}

class _UserTabsState extends State<UserTabs> {
  List<PageViewModel> pageViewModel = [
    PageViewModel(
      title: "إختر مسار الحافلة",
       body:
          "بإختيارك للمسار سيكون موقعك ظاهراً لجميع الحافلات على هذا المسار",
      image: Center(
        child: Container(
          margin: EdgeInsets.only(top: 10.h),
          child: Image.asset(
            "assets/images/tabs3.png",
            //height: 200.h,
            width: 60.w,
          ),
        ),
      ),
    ),
    PageViewModel(
      title: "تتبع حركة الحافلات",
      body:
          "بمجرد دخولك لهذه الصفحة ستظهر لديك جميع الحافلات التي تعمل الان على المسار المختار",
      image: Center(
        child: Image.asset(
          "assets/images/tabs2.png",
          width: 60.w,
        ),
      ),
    ),
    PageViewModel(
      title: "كٌن مستعداً",
      body:
          "إحرص على الوصول لأقرب نقطة التقاء على المسار قبل وصول الحافلة اليك",
      image: Center(
        child: Image.asset(
          "assets/images/tabs1.png",
          width: 60.w,
        ),
      ),
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IntroductionScreen(

          showSkipButton: true,
          pages: pageViewModel,
          onDone: () {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                    builder: (c) => UserSelectRoute()),
                (route) => false);
          },
          onSkip: () {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                    builder: (c) => UserSelectRoute()),
                (route) => false);
          },
          next: const Icon(Icons.arrow_forward_ios),
          showNextButton: true,
          done: const Text(
            "البدء",
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
          skip: const Text("تخطي"),
          dotsDecorator: DotsDecorator(
              size: const Size.square(10.0),
              activeSize: const Size(20.0, 10.0),
              activeColor: Colors.blue,
              color: Colors.black26,
              spacing: const EdgeInsets.symmetric(horizontal: 3.0),
              activeShape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0)))),
    );
  }
}
