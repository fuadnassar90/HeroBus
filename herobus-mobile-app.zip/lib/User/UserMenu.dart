import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import '../Resources/LayoutController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/Backend/Cashe/preferances.dart';
import 'package:herobus/CustomWidgets/CustomArrowBack.dart';
import 'package:herobus/CustomWidgets/CustomRaisedButton.dart';
import 'package:herobus/CustomWidgets/CustomTextField.dart';
import 'package:herobus/LoginAs.dart';
import 'package:herobus/dialogs/error.dart';
import 'package:herobus/Resources/Resources.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:sizer/sizer.dart';
class UserMenu extends StatefulWidget {

  UserMenu();

  @override
  _UserMenuState createState() => _UserMenuState();
}

class _UserMenuState extends State<UserMenu> {
  String phone;
  bool ok = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: <Widget>[
        SingleChildScrollView(
          child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              child: Image(
                image: AssetImage('assets/images/mask_profile.png'),
                fit: BoxFit.cover,
              )),
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          height: LayoutController.getHeight(
              (MediaQuery.of(context).size.height - 60),
              minHeight: 740),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                decoration: BoxDecoration(
                    color: R.colors.whiteMainColor,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(25),
                        topRight: Radius.circular(25))),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * .40,
                child: ok
                    ? column()
                    : SingleChildScrollView(
                        child: Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(top: 70),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      IconButton(
                                          icon: Image.asset(
                                            'assets/images/facebook.png',
                                            width: 10.w,
                                            height: 10.h,
                                          ),
                                          padding: EdgeInsets.zero,
                                          onPressed: () async {
                                            String url = 'https://fb.me/herobusltd';
                                            await canLaunch(url)
                                                ? await launch(url)
                                                : throw 'Could not launch $url';
                                          }
                                      ),
                                      IconButton(
                                          icon: Image.asset(
                                            'assets/images/whatsapp.png',
                                            width: 10.w,
                                            height: 10.h,
                                          ),
                                          padding: EdgeInsets.zero,
                                          onPressed: () async {
                                            String url = 'https://wa.me/+962785755223';
                                            await canLaunch(url)
                                                ? await launch(url)
                                                : throw 'Could not launch $url';
                                          }

                                      ),
                                      IconButton(
                                          icon: Image.asset(
                                            'assets/images/youtube.png',
                                            width: 10.w,
                                            height: 10.h,
                                          ),
                                          padding: EdgeInsets.zero,
                                          onPressed:() async {
                                            String url = 'https://www.youtube.com/channel/UCaOkpeNfxvFAH4ND--hmG2A';
                                            await canLaunch(url)
                                                ? await launch(url)
                                                : throw 'Could not launch $url';
                                          }
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(0, 30, 0, 30),
                              child: ButtonTheme(
                                height: 7.h,
                                minWidth:
                                    MediaQuery.of(context).size.width - 40,
                                child: CustomRaisedButton(
                                  text: "تسجيل الخروج",
                                  borderColor: R.colors
                                      .splashScreenViewPagerSelectedIndicatorColor,
                                  textColor: R.colors
                                      .splashScreenViewPagerSelectedIndicatorColor,
                                  color: Colors.white,
                                  onPressed: () async {
                                    // await EasyLoading.show(status: 'Logging out..');
                                    // await AuthController.logout(token: widget.token);
                                    // await EasyLoading.dismiss();
                                    // Urls.errorMessage == 'no'
                                    //     ? Navigator.pushAndRemoveUntil(
                                    //         context,
                                    //         MaterialPageRoute(
                                    //             builder: (c) => LoginAs()),
                                    //         (route) => false)
                                    //     : errorWhileOperation(
                                    //         errorMessage: Urls.errorMessage,
                                    //         context: context,
                                    //         buttonText: 'Try Again',
                                    //         func: () {
                                    //           Navigator.pop(context);
                                    //         });
                                    cache.token='';
                                    await DataInLocal.saveInLocal(
                                        token: '0', role: '0',id:'0');
                                    Navigator.pushAndRemoveUntil(
                                        context,
                                        MaterialPageRoute(
                                            builder: (c) => LoginAs()),
                                        (route) => false);
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
              ),
            ],
          ),
        ),
        CustomArrowBack()
      ],
    ));
  }

  Column column() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          'assets/images/mail.png',
          width: 100,
          height: 100,
        ),
        Text(
          'تم استلام طلب انضمامك',
          style: TextStyle(
              color: R.colors.homeTextColor,
              fontFamily: R.strings.fontName,
              fontSize: 25,
              fontWeight: FontWeight.w500),
          textAlign: TextAlign.start,
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          'عزيزنا العميل، نحن بصدد مراجعة طلبك\n سيتم معالجة الطلب خلال 24 ساعة\n نشكرك كونك جزء من Hero Bus',
          style: TextStyle(
              color: R.colors.homeTextColor,
              fontFamily: R.strings.fontName,
              fontSize: 25,
              fontWeight: FontWeight.w500),
          textAlign: TextAlign.center,
        ),
        SizedBox(
          height: 10,
        ),
        CustomRaisedButton(
          text: "رجوع",
          borderColor: R.colors.splashScreenViewPagerSelectedIndicatorColor,
          textColor: R.colors.splashScreenViewPagerSelectedIndicatorColor,
          color: Colors.white,
          onPressed: () {
            setState(() {
              ok = false;
            });
          },
        ),
      ],
    );
  }
}

// arrow back btn
// Padding(
// padding: const EdgeInsets.fromLTRB(20, 30, 0, 0),
// child: Container(
// color: Colors.blueAccent,
// child: IconButton(
// icon: Icon(Icons.arrow_back),
// color: Colors.white,
// onPressed: () {
// Navigator.pop(context);
// },
// ),
// ),
// ),
