import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';

class CustomUserMapMaxMinData extends Bloc<CustomUserMapMaxMinDataEvent, bool> {
  CustomUserMapMaxMinData(bool initialState) : super(initialState);

  bool get initialState => false;

  @override
  Stream<bool> mapEventToState(CustomUserMapMaxMinDataEvent event) async* {
    // TODO: implement mapEventToState
    switch (event) {
      case CustomUserMapMaxMinDataEvent.maximise:
        yield false;
        break;
      case CustomUserMapMaxMinDataEvent.minimise:
        yield true;
        break;
    }
  }
}

enum CustomUserMapMaxMinDataEvent { maximise, minimise }
