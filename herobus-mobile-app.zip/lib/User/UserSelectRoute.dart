import 'dart:convert';

import 'package:adhara_socket_io/adhara_socket_io.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import '../Backend/controller/AutheticationController.dart';
import 'package:herobus/Backend/controller/urls.dart';
import 'package:herobus/User/Map/UserMap.dart';
import 'package:sizer/sizer.dart';

class UserSelectRoute extends StatefulWidget {
  UserSelectRoute();

  @override
  _UserSelectRouteState createState() => _UserSelectRouteState();
}

class _UserSelectRouteState extends State<UserSelectRoute> {
  TextEditingController controller = new TextEditingController();
  SocketIOManager manager;
  SocketIO socket;
  Map<String, Object> map_names = new Map<String, Object>();
  Map<String, Object> map_count_buses = new Map<String, Object>();
  Map<String, Object> map_names_search = new Map<String, Object>();
  Map<String, Object> map_count_buses_search = new Map<String, Object>();

  // Get json result and convert it to model. Then add
  Future<Null> getAllRoutes() async {
    Response response;
    Dio dio = new Dio();

    await dio.get(Urls.getAllRoutesUrl).then((value) {
      // final responseJson = json.decode(jsonEncode(value.data));

      (value.data as List).forEach((element) {
        map_names[element['id'].toString()] = element['name'].toString();
        map_count_buses[element['id'].toString()] =
            element['current_work_buses'].toString();
      });
      print(map_names['1']);
      print(map_count_buses['1']);

// print(value.data[0]['name']);
      setState(() {
//         _routeDetails = value.data;
//
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getAllRoutes();
    manager = SocketIOManager();
    initSocket();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Container(
        alignment: Alignment.topRight,
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text("إختر مسار الحافلة"),
          SizedBox(width: 20),
          Image.asset(
            'assets/images/route.png',
            width: 10.w,
          ),
        ]),
      )),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              margin: EdgeInsets.fromLTRB(0, 8, 20, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[],
              ),
            ),
            Container(
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                  child: Card(
                    child: TextField(
                      controller: controller,
                      decoration: InputDecoration(
                        labelText: "ابحث",
                        hintText: "ادخل اسم الخط",
                        hintStyle: TextStyle(
                            fontSize: 8.sp, fontWeight: FontWeight.w800),
                        labelStyle: TextStyle(
                            fontSize: 14.sp, fontWeight: FontWeight.w800),
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(),
                      ),
                      onChanged: onSearchTextChanged,
                    ),
                  ),
                ),
              ),
              height: MediaQuery.of(context).size.height * 0.12,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 5),
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Text(
                  'عزيزنا العميل، قد لا تجد جميع الخطوط الذي ترغب بها. نتفهم ذلك ونحن بصدد اضافة المزيد من الخطوط قريباً',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    color: Colors.red,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Container(

              width: double.infinity,
              height: MediaQuery.of(context).size.height * 0.665,
              child: controller.text.isNotEmpty
                  ? ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: map_names_search.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                            onTap: () async {
                              await EasyLoading.show(status: null);
                              await AuthController.initMapUser(
                                  id_route: map_names_search.keys
                                      .elementAt(index)
                                      .toString());
                              await EasyLoading.dismiss();
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (c) => UserMap(
                                          //  token: widget.token,
                                          // role: 'user'
                                          )));
                            },
                            child: Padding(
                              padding: EdgeInsets.only(bottom: 8,top: 2),
                              child: Card(
                                shadowColor: Colors.blue,
                                elevation: 5,
                                margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                                child: ListTile(
                                  contentPadding: EdgeInsets.symmetric(
                                      horizontal: 2.w, vertical: 2.0.h),
                                  trailing: Container(
                                    padding: EdgeInsets.only(right: 12.0),
                                    decoration: new BoxDecoration(
                                        border: new Border(
                                            left: new BorderSide(
                                                width: 2.0,
                                                color: Colors.blueAccent))),
                                    child: Icon(
                                      Icons.directions_bus,
                                      color: Colors.blueAccent,
                                      size: 8.w,
                                    ),
                                  ),
                                  title: Text(
                                    map_names_search.values
                                        .elementAt(index)
                                        .toString(),
                                    style: TextStyle(
                                        fontSize: 12.sp, // SEARCH
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                    textAlign: TextAlign.end,
                                  ),
                                  // subtitle: Text("Intermediate", style: TextStyle(color: Colors.white)),

                                  subtitle: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: <Widget>[
                                      Text(
                                          '${map_count_buses_search.values.elementAt(index).toString()} : الحافلات النشطة حاليا ً',
                                          style: TextStyle(
                                              fontSize: 10.sp,
                                              color: Colors.black54)),
                                    ],
                                  ),
                                  leading: Icon(Icons.keyboard_arrow_left,
                                      color: Colors.black45, size: 10.w),
                                ),
                              ),
                            ));
                      },
                    )
                  : ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: map_names.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                            onTap: () async {
                              await EasyLoading.show(status: null);
                              await AuthController.initMapUser(
                                  id_route: map_names.keys
                                      .elementAt(index)
                                      .toString());
                              await EasyLoading.dismiss();
                              Navigator.push(context,
                                  MaterialPageRoute(builder: (c) => UserMap()));
                            },
                            child: Padding(
                              padding: EdgeInsets.only(bottom: 8,top: 2),
                              child: Card(
                                shadowColor: Colors.blue,
                                elevation: 5,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                                margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                child: ListTile(
                                  contentPadding: EdgeInsets.symmetric(
                                      horizontal: 2.w, vertical: 2.0.h),
                                  trailing: Container(
                                    padding: EdgeInsets.only(right: 12.0),
                                    decoration: new BoxDecoration(
                                        border: new Border(
                                            left: new BorderSide(
                                                width: 2.0,
                                                color: Colors.blueAccent))),
                                    child: Icon(
                                      Icons.directions_bus,
                                      color: Colors.blueAccent,
                                      size: 8.w,
                                    ),
                                  ),
                                  title: Text(
                                    map_names.values
                                        .elementAt(index)
                                        .toString(),
                                    style: TextStyle(
                                        fontSize: 12.sp,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                    textAlign: TextAlign.end,
                                  ),
                                  // subtitle: Text("Intermediate", style: TextStyle(color: Colors.white)),

                                  subtitle: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: <Widget>[
                                      Text(
                                          '${map_count_buses.values.elementAt(index).toString()} : الحافلات النشطة حاليا ً',
                                          style: TextStyle(
                                              fontSize: 10.sp,
                                              color: Colors.black54)),
                                    ],
                                  ),
                                  leading: Icon(Icons.keyboard_arrow_left,
                                      color: Colors.black45, size: 10.w),
                                ),
                              ),
                            ));
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // List<dynamic> _searchResult = [];
  //
  // List<dynamic> _routeDetails = [];

  onSearchTextChanged(String text) async {
    map_names_search.clear();
    map_count_buses_search.clear();
    if (text.isEmpty) {
      setState(() {
        // _searchResult=_routeDetails;
      });
      return;
    }

    // _routeDetails.forEach((routeDetail) {
    //   print(routeDetail['name'] +
    //       " is contains $text :" +
    //       routeDetail['name'].contains(text).toString());
    //   if (routeDetail['name'].contains(text)) {
    //     _searchResult2.add(routeDetail);
    //     print('_searchResult:' + _searchResult.toString());
    //   }
    // });
    map_names.forEach((key, value) {
      if (value.toString().contains(text)) {
        var current_count_buses = map_count_buses[key.toString()];
        map_count_buses_search[key.toString()] = current_count_buses;
        map_names_search[key.toString()] = value;
      }
    });
    setState(() {});
    // for (int i = 0; i < map_names.length; i++) {
    //   var routeDetail = _routeDetails[i];
    //   // print(routeDetail['name'] +
    //   //     " is contains $text :" +
    //   //     routeDetail['name'].contains(text).toString());
    //   if (routeDetail['name'].contains(text)) {
    //     _searchResult.add(routeDetail);
    //     print('_searchResult:' + _searchResult.toString());
    //   }
    //   if (i == _routeDetails.length - 1) {
    //     print('_searchResult.length =' + _searchResult.length.toString());
    //
    //     setState(() {
    //       // _searchResult = _searchResult;
    //     });
    //   }
    // }
  }

  @override
  void dispose() {
    disconnect();
    super.dispose();
  }

  initSocket() async {
    socket = await manager.createInstance(SocketOptions(Urls.API_SOCKET_URL,
        nameSpace: "/",
        query: {
          "id_route": 'routes',
        },
        enableLogging: false,
        transports: [Transports.WEB_SOCKET]));
    socket.onConnect((data) {
      pprint("success connected to routes socket...");
    });
    socket.onConnectError(pprint);
    socket.onConnectTimeout(pprint);
    socket.onError(pprint);
    socket.onDisconnect(pprint);
    socket.on("update_data", (data) {
      String action = data['action'].toString();
      String id_route = data['id_route'].toString();
      String current_work_buses = data['current_work_buses'].toString();
      pprint(data);
      setState(() {
        map_count_buses[id_route] = current_work_buses;
      });

      // var iter= _routeDetails.firstWhere((element) {
      //
      //   print(' oo '+element.id.toString());
      //   print(' ddd '+element['id'].toString());
      //   if(element.id==id_route){
      //
      //
      //     print(element);
      //     return false;
      //   }
      //   return false;});
      // print('iter: ' +iter);

      // List id_split = data['id'].toString().split('.');
      // String busId = id_split[1];
      // List splitCoord = data['location'].toString().split(',');
      // double busLat = double.parse(splitCoord[0].toString());
      // double busLng = double.parse(splitCoord[1].toString());

      // setState(() {
      //   _routeDetails[_routeDetails.indexWhere((element) {
      //     print(element.uid);
      //     return true;
      //   } )] = _routeDetails;
      //
      // });
    });
    socket.connect();
  }

  disconnect() async {
    await manager.clearInstance(socket);
  }

  pprint(data) {
    setState(() {
      if (data is Map) {
        data = json.encode(data);
      }
      print(data);
    });
  }
}

// final String url = 'https://herobus.herokuapp.com/app/users/getallroutes';

// class RouteDetails {
//   final int id;
//   final String name;
//   final int current_work_buses;
//
//   RouteDetails({this.id, this.name, this.current_work_buses});
//
//   factory RouteDetails.fromJson(Map<String, dynamic> json) {
//     return new RouteDetails(
//       id: json['id'],
//       name: json['name'],
//       current_work_buses: json['current_work_buses'],
//     );
//   }
// }
