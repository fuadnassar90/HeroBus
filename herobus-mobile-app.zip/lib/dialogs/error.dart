import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:herobus/Backend/controller/urls.dart';

Future<void> errorWhileOperation(
    {@required String errorMessage,
    @required BuildContext context,
    @required String buttonText,
    @required Function func}) {
  return showCupertinoDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(
        'حدث خطأ',
        textDirection: TextDirection.rtl,
      ),
      content: Text(
        errorMessage != null ? errorMessage : Urls.errorMessage,
        style: TextStyle(color: Colors.black),
        textDirection: TextDirection.rtl,
      ),
      actions: <Widget>[
        TextButton(
          onPressed: func,
          child: Text(
            buttonText,
            style: TextStyle(color: Colors.blueAccent),
          ),
        ),
      ],
    ),
  );
}
