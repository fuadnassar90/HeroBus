// import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:herobus/Backend/Cashe/cache.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:url_launcher/url_launcher.dart';
// import 'package:herobus/Backend/controller/urls.dart';

Future<void> updateOperation(
    {@required String errorMessage,
    @required BuildContext context,
    @required String buttonText,
    @required Function func}) {
  return Alert(
    context: context,
    onWillPopActive: true,
    closeIcon: Icon(Icons.anchor_outlined),
    closeFunction: () {},
    type: AlertType.warning,
    title: "اصدار جديد",
    desc: "هنالك تحديث جديد للتطبيق يتوجب عليك تحميله",
    buttons: [
      DialogButton(
        child: Text(
          "حمل التحديث",
          style: TextStyle(color: Colors.white, fontSize: 20),
          textAlign: TextAlign.center,
        ),
        onPressed: () async {
          String url = cache.storeURL;
          if (await canLaunch(url)) {
            await launch(url);
            SystemNavigator.pop();
          } else {
            throw 'Could not launch $url';
          }
        },
        width: 120,
      )
    ],
  ).show();

  // return showCupertinoDialog<void>(
  //   context: context,
  //   builder: (context) => Alert(
  //     context: context,
  //     type: AlertType.error,
  //     title: "RFLUTTER ALERT",
  //     desc: "Flutter is more awesome with RFlutter Alert.",
  //     buttons: [
  //       DialogButton(
  //         child: Text(
  //           "COOL",
  //           style: TextStyle(color: Colors.white, fontSize: 20),
  //         ),
  //         onPressed: () => Navigator.pop(context),
  //         width: 120,
  //       )
  //     ],
  //   ),
  // );
}
