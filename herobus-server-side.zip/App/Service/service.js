//const { static } = require('express');
//const express = require('express');
const request = require('request');
const tempInfo = require('../Entity/TempInfo');
const jwt = require('jsonwebtoken');
const compareVersions = require('compare-versions');
// const registrationToken = 'AAAAxnKzkvU:APA91bELkrWHQy7ZoDXbjBD3zumkHMbsxxhI7333uEfWFihxu3EBcSCiL7li9Wkj6vIiUH289rUvj9hydfvVD0-WghDbBo0z-J88BHp1nba_SypzltIaLhKoSX2Mq6SkTibYpR7tlXyq';
var phoneToken = require('generate-sms-verification-code')
const {
    encrypt,
    decrypt,
    isMatch
} = require.main.require('./mylib/crypto');
//const encrypt = require.main.require('./mylib/crpyto.js');
const NodeRSA = require('node-rsa');
const ACCESS_TOKEN_SECRET = 'd38c6bdd6d406c331cd94d6f63480097e12894957b041aabe957ebfb257ad352dda35e956206da30e2d9c8f1716adfeda5a205b35b5662a4df48c472f925b960'
var admin = require("firebase-admin");
const key = new NodeRSA({
    b: 512
});
const {
    Client
} = require('pg');
const db = new Client({
    user: "biapwskdrvyjfh",
    password: "fd0bcc9345f8e1123b54531c40199903d370c370844ab9034aca1876d763d378",
    host: "ec2-54-155-226-153.eu-west-1.compute.amazonaws.com",
    port: "5432",
    database: "dfrogsh6j94e5v",
    ssl: {
        rejectUnauthorized: false
    }
});
db.connect();

module.exports = {
    getDatabase() {
        return db;
    },
    driverAuthToken: (req, resApi, next) => {
        const authHeader = req.headers['authorization'];
        console.log('authHeader: '+authHeader);
        const token = authHeader && authHeader.split(' ')[1];
        if (token == null) return resApi.sendStatus(401);

        jwt.verify(token, ACCESS_TOKEN_SECRET, (err, payload) => {
            if (err) {
                return resApi.sendStatus(403);
            } else {
                req.payload = payload;

                db.query("SELECT pass FROM drivers_info WHERE phone='" + req.payload.phone + "'", (err, res) => {
                    if (err || res.rows.length == 0) {
                        console.log(err);
                    }
                    // console.log("req.payload: "+ req.payload);
                    console.log('req.payload.pass:'+req.payload.pass);
                    console.log('res.rows[0].pass:'+res.rows[0].pass);
                    if (isMatch(req.payload.pass, res.rows[0].pass)) {
                        next();
                    } else {
                        resApi.status(403).send("الخطأ: تم تغير كلمة السر");
                    }
                });
            }
        });
    },
    userAuthToken: (req, resApi, next) => {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        if (token == null) return res.sendStatus(401);
        jwt.verify(token, ACCESS_TOKEN_SECRET, (err, payload) => {
            if (err) {
                return resApi.sendStatus(403);
            } else {
                req.payload = payload;
                next();
            }
        });
    },
//    adminAuthToken: (req, resApi, next) => {
//            const authHeader = req.headers['authorization'];
//            const token = authHeader && authHeader.split(' ')[1];
//            if (token == null) return res.sendStatus(401);
//            jwt.verify(token, ACCESS_TOKEN_SECRET, (err, payload) => {
//                if (err){ return res.sendStatus(403);}else{
//                req.payload = payload;
//                db.query("SELECT pass FROM admins_info WHERE phone='" + req.payload.phone + "'", (err, res) => {
//                    if (err || res.rows.length==0)  {console.log(err);}
//                    if (isMatch(req.payload.pass, res.rows[0].pass)) {
//                        next();
//                    } else {
//                        resApi.status(403).send("الخطأ: تم تغير كلمة السر");
//                    }
//                });
//    }
//            });
//        },
    test: (req, resApi) => {
        resApi.json({
            message: "test driver function"
        });

    },
    addBusOrder: (req, resApi) => {
        var id_bus;
        let status_msg = 'سيقوم فريقنا بالتواصل معك على رقم هاتفك نشكرك على كونك جزء من هيرو باص';
        const sql1 = {
            text: 'INSERT INTO buses_info(name,no_plate,is_push_enable,is_work_now,drivers_count,push_token,status,status_msg) values($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id;',
            values: [req.body.name_route, req.body.no_plate, true, false, 1, req.body.push_token, 'pending', status_msg],
        };
        db.query(sql1, (err, res1) => {
            if (err || res1.rows.length == 0) {
                const errMsg = err.message;
                console.log(errMsg);
                if (errMsg.includes('unique constraint')) {
                    resApi.status(400).send("الخطأ: رقم لوحة الحافلة مسجل مسبقا");
                } else {
                    resApi.status(500).send("الخطأ: يوجد مشكلة في بيانات الحافلة");
                }
            } else {
                id_bus=res1.rows[0].id;
                const sql2 = {
                    text: 'INSERT INTO drivers_info(id_bus,phone,pass) values($1,$2,$3)',
                    values: [id_bus, req.body.phone, encrypt(req.body.pass)],
                };


                db.query(sql2, (err, res2) => {

                    if (err || res1.rows.length == 0) {
                        db.query("delete from buses_info where id=" + res1.rows[0].id, (err, res) => {
                            if (err) {
                                console.log(err);
                            }
                        });

                        const errMsg = err.message;
                        console.log(errMsg);
                        if (errMsg.includes('unique constraint')) {
                            resApi.status(400).send("الخطأ: رقم الهاتف مسجل مسبقا, يجب التسجيل برقم مختلف");
                        } else {
                            resApi.status(500).send("الخطأ: يوجد مشكلة في بيانات السائق");
                        }
                    } else {
                        const ACCESS_TOKEN = jwt.sign({
                            phone: req.body.phone,
                            pass: req.body.pass
                        }, ACCESS_TOKEN_SECRET);
                        resApi.send(id_bus+":"+ACCESS_TOKEN);
                    }

                });
            }


        });

    },
    getAllBusesOrders: (req, resApi) => {
        db.query("SELECT buses_info.id, buses_info.name, buses_info.no_plate,drivers_info.phone FROM buses_info FULL OUTER JOIN drivers_info ON buses_info.id=drivers_info.id_bus where buses_info.status='pending' ORDER BY id DESC", (err, res) => {
            if (err) {
                console.log(err);
            }
            resApi.send(res.rows);
        });
    },
    acceptBusOrder: (req, resApi) => {
        const id_bus = req.body.id_bus;
        const id_route = req.body.id_route;
        const no_plate = req.body.no_plate;
        db.query("SELECT COUNT(*) from routes_info where id=" + id_route, (err, res) => {
            if (err) {
                console.log(err);
            }
            const isExist = (res.rows[0].count > 0);
            if (isExist) {
                //executeQuery("UPDATE routes_info SET count_buses = count_buses + 1 WHERE id ="+id_route);
                console.log("UPDATE routes_info SET count_buses = count_buses + 1 WHERE id = " + id_route + " RETURNING count_buses;");
                db.query("UPDATE routes_info SET count_buses = count_buses + 1 WHERE id = " + id_route + " RETURNING count_buses;", (err, res) => {
                    if (err) {
                        console.log(err);
                    }
                    const count_buses = res.rows[0].count_buses;
                    const name_bus = "B" + count_buses;

                    db.query("UPDATE buses_info SET name='" + name_bus + "',status='accepted',status_msg='',id_route='"+id_route+"' where id=" + id_bus + " RETURNING push_token;", (err, res) => {
                        if (err) {
                            console.log(err);
                        }

                        console.log('res.rows[0].push_token:'+res.rows[0].push_token);
                        sendPushNotification('تم قبول طلب انضمامك بنجاح','لمتابعة ابرز الاحداث بامكانك زيارة صفحتنا على الفيس بوك',res.rows[0].push_token);
                        resApi.send("done");
                });

                });

            } else {
                resApi.status(404).send("الخطأ: خط الحافلة غير موجود");
            }

        });


    },
    rejectBusOrder: (req, resApi) => {
        const id_bus = req.body.id_bus;
        // const msg = req.body.msg;
        executeQuery("UPDATE buses_info SET status_msg='" + "" + "',status='rejected' where id=" + id_bus);
        ///-------------------------- Should send push notification to drivers
        resApi.send("done");
    },
    deleteBusOrder: (req, resApi) => {
        db.query("SELECT id_bus from drivers_info where id=" + req.params.id, (err, res) => {
            if (err) {
                console.log(err);
            }
            console.log(res.rows.length);
            if (res.rows.length > 0) {
                db.query("delete from buses_info where id=" + res.rows[0].id_bus, (err, res) => {
                    if (err) {
                        console.log(err);
                    }
                    db.query("delete from drivers_info where id=" + req.params.id, (err, res) => {
                        if (err) {
                            console.log(err);
                        }
                        resApi.send("done");
                    });
                });
            } else {
                resApi.sendStatus(204);
            }
        });
    },
    driverInitLogin: (req, resApi) => {
        const phone = req.body.phone;
        const pass = req.body.pass;
        const push_token = req.body.push_token;
        db.query("SELECT COUNT(*) FROM drivers_info WHERE phone='" + phone + "'", (err, res) => {
            if (err) {
                console.log(err);
            }
            if (res.rows[0].count == 0) {
                resApi.status(404).send("الخطأ: رقم الهاتف المدخل غير صحيح");
            } else {
                db.query("SELECT id,pass,id_bus FROM drivers_info WHERE phone='" + phone + "'", (err, res) => {
                    if (err) {
                        console.log(err);
                    }
                    if (isMatch(pass, res.rows[0].pass)) {
                        const ACCESS_TOKEN = jwt.sign({
                            phone: phone,
                            pass: pass
                        }, ACCESS_TOKEN_SECRET);
                        // resApi.send(res.rows[0].id + ":" + ACCESS_TOKEN); /// ......
                        resApi.send(res.rows[0].id_bus + ":" + ACCESS_TOKEN);
                        console.log("UPDATE buses_info SET push_token='" + push_token + "' WHERE id='" + res.rows[0].id_bus + "'");
                        db.query("UPDATE buses_info SET push_token='" + push_token + "' WHERE id='" + res.rows[0].id_bus + "'", (err, res) => {
                            if (err) {
                                console.log(err);
                            }});
                    } else {
                        resApi.status(400).send("الخطأ: كلمة المرور المدخلة غير صحيحة");

                    }

                });

            }
        });
        //ty
    },
    driverAutoLogin: (req, resApi) => {
        var os = req.body.os;
        var app_version = req.body.version;
        var drivers;
        var bus;
        var route;
//        console.log('current os is '+ os+' and version is '+app_version);
        db.query("SELECT id,id_bus,phone FROM drivers_info WHERE id_bus=(SELECT id_bus FROM drivers_info where phone='" + req.payload.phone + "')", (err, res) => {
            if (err) {
                console.log(err);
            }
            const id_bus = res.rows[0].id_bus;
            drivers = res.rows;
            db.query(os == 'android' ? 'SELECT android_version FROM constants' : 'SELECT ios_version FROM constants', (err, res) => {
                if (err) {
                    console.log(err);
                }
                var server_version = os == 'android' ? res.rows[0].android_version : res.rows[0].ios_version;
//console.log('server_version is:'+server_version);
                var is_need_update = compareVersions(server_version, app_version) > 0;
//console.log('is_need_update is:'+is_need_update);
                if (!is_need_update) {
                    db.query("SELECT * FROM buses_info WHERE id=" + id_bus, (err, res) => {
                        if (err) {
                            console.log(err);
                        }
                        bus = res.rows[0];

                        console.log('status:' + res.rows[0].status);
                        if (res.rows[0].status == 'accepted') {
                            db.query("SELECT * FROM routes_info WHERE id=" + res.rows[0].id_route, (err, res) => {
                                if (err) {
                                    console.log(err);
                                }
                                route = res.rows[0];
                                resApi.status(200).send({
                                    "route": route,
                                    "bus": bus,
                                    "drivers": drivers
                                });
                            });
                        } else if (res.rows[0].status == 'pending') {
                            resApi.status(403).send('الخطأ: الحساب غير مفعل');
                        } else if (res.rows[0].status == 'rejected') {
                            resApi.status(403).send('الخطأ: نعتذر لا يمكننا قبول طلب انضمامك, لمعرفة الاسباب تواصل معنا عبر الواتس اب');
                        } else if (res.rows[0].status == 'blocked') {
                            resApi.status(403).send('الخطأ: تم الغاء تنشيط حسابك');
                        }

                    });
                } else {
                    resApi.status(428).send('الخطأ: هنالك تحديث جديد للتطبيق يتوجب عليك تحميله');
                }
            });
        });
    },
    updateDriverPass: (req, resApi) => {
        const phone = req.payload.phone;
        const pass = encrypt(req.body.new_pass);
        console.log('phone:' + phone);
        console.log('pass:' + pass);

        db.query("UPDATE drivers_info SET pass = '" + pass + "' WHERE phone='" + phone + "' RETURNING id_bus", (err, res) => {
            if (err) {
                console.log(err);
            }
            const ACCESS_TOKEN = jwt.sign({
                phone: phone,
                pass: req.body.new_pass
            }, ACCESS_TOKEN_SECRET);
            console.log('ACCESS_TOKEN:' + ACCESS_TOKEN);
            resApi.send(res.rows[0].id_bus + ":" + ACCESS_TOKEN);

        });
    },
    sendSMS: (req, resApi) => {
        db.query("SELECT phone FROM drivers_info WHERE phone='" + req.body.phone + "'", (err, res) => {
            if (err || res.rows.length == 0) {
                resApi.status(404).send("الخطأ: رقم الهاتف غير مسجل");
            } else {
                var generatedToken = phoneToken(4, {
                    type: 'string'
                })
                console.log(generatedToken)
                sendSMSToPhone("كود التحقق: " + generatedToken, req.body.phone);
                /// ------------------------------- send generatedToken to phone by relans sms
                resApi.send(encrypt(generatedToken + ""))
            }
        });


    },
    checkSMS: (req, resApi) => {
        if (isMatch(req.body.code, req.body.hash)) {
            console.log("SELECT pass FROM drivers_info WHERE phone='" + req.body.phone + "'");
            db.query("SELECT pass FROM drivers_info WHERE phone='" + req.body.phone + "'", (err, res) => {
                console.log(res.rows.length);
                if (err || res.rows.length == 0) {
                    resApi.status(404).send("الخطأ: رقم الهاتف غير مسجل");
                } else {
                    const ACCESS_TOKEN = jwt.sign({
                        phone: req.body.phone,
                        pass: decrypt(res.rows[0].pass)
                    }, ACCESS_TOKEN_SECRET);
                    resApi.send(ACCESS_TOKEN);

                }

            });

        } else {
            resApi.status(400).send("الخطأ: الكود المدخل غير صحيح");
        }
    },
    addDriver: (req, resApi) => {
        const mainPhone = req.payload.phone;
        const phone = req.body.phone;
        const encrypt_pass = encrypt(req.body.pass);
        console.log(mainPhone);
        db.query("INSERT INTO drivers_info (id_bus,phone,pass) VALUES((SELECT id_bus FROM drivers_info WHERE phone='" + mainPhone + "'),'" + phone + "','" + encrypt_pass + "')", (err, res) => {
            if (err) {
                const errMsg = err.message;
                console.log(errMsg);
                if (errMsg.includes('unique constraint')) {
                    resApi.status(400).send("الخطأ: رقم الهاتف مسجل مسبقا, يجب التسجيل برقم مختلف");
                } else {
                    resApi.status(500).send("الخطأ: يوجد مشكلة في بيانات الحافلة");
                }
            } else {
                executeQuery("UPDATE buses_info SET drivers_count=(drivers_count+1) WHERE id=(SELECT id_bus from drivers_info WHERE phone='" + phone + "') ");
                selectQuery("SELECT id,id_bus,phone FROM drivers_info WHERE phone='" + phone + "'", resApi);

            }
        });
    },
    deleteDriver: (req, resApi) => {
        const authPhone = req.payload.phone;
        const id_driver_deleted = req.params.id;
        db.query("SELECT id_bus,id FROM drivers_info WHERE phone='" + authPhone + "';", (err, res) => {
            if (err || res.length == 0) {
                console.log(err);
            }
            if (res.rows[0].id == id_driver_deleted) {
                resApi.status(400).send("الخطأ: لا يمكنك حذف حسابك");
            } else {


                const id_bus = res.rows[0].id_bus;
                db.query("SELECT COUNT(id_bus) FROM drivers_info WHERE id_bus=" + id_bus, (err, res) => {
                    if (err || res.length == 0) {
                        console.log(err);
                    }
                    const count = res.rows[0].count;
                    if (count > 1) {
                        executeQuery("DELETE FROM drivers_info WHERE id=" + id_driver_deleted + " and id_bus=" + id_bus);
                        resApi.sendStatus(200);
                    } else {
                        resApi.status(400).send("الخطأ: يجب الابقاء على سائق واحد على الاقل");
                    }
                });
            }
        });
    },
    getAllRoutes: (req, resApi) => {

        selectQuery("SELECT id,name,current_work_buses FROM routes_info WHERE is_live='true' ORDER BY id ASC;", resApi);
//         db.query("SELECT id,name,current_work_buses FROM routes_info WHERE is_live='true' ORDER BY id ASC;", (err, res) => {
//                var all_routes = new Map();
//                if (err)  {console.log(err);}
//                var map=new Map();
//                for(let i=0;i<res.rows.length;i++){
//                var row=res.rows[i];
//                var id=row['id'].toString();
//                var name=row['name'].toString();
//              var map = new Map();
//                     map.set('name', row['name'].toString());
//                     all_routes.set(id, [...map]);
//
////                console.log([''+id:['name':row['name'].toString(),'current_work_buses':row['current_work_buses'].toString()]]);
//                if(i==res.rows.length-1){
//                 resApi.send([...all_routes]);
//                }
//                }
//
//            });

    },
    sendSuggestion: (req, resApi) => {
        insertIntoUniqeTable(req, resApi, "users_suggestions", {
            "id_user": req.payload.id,
            "msg": req.body.msg
        });
    },
    userInitLogin: (req, resApi) => {
        var os = req.body.os;
        var app_version = req.body.version;
        db.query(os == 'android' ? 'SELECT android_version FROM constants' : 'SELECT ios_version FROM constants', (err, res) => {
            if (err) {
                console.log(err);
            }
            var server_version = os == 'android' ? res.rows[0].android_version : res.rows[0].ios_version;
            console.log('app_version is:' + app_version);
            console.log('server_version is:' + server_version);
            console.log('compareVersions(server_version, app_version) is:' + compareVersions(server_version, app_version));
            var is_need_update = compareVersions(server_version, app_version) > 0;
            if (!is_need_update) {
                db.query("INSERT INTO users_info(push_token) VALUES('" + req.body.push_token + "') RETURNING id;", (err, res) => {
                    if (err) {
                        console.log(err);
                    }
                    console.log(res.rows[0].id);
                    const ACCESS_TOKEN = jwt.sign({
                        id: res.rows[0].id
                    }, ACCESS_TOKEN_SECRET);
                    console.log('user token is' + ACCESS_TOKEN);

                    resApi.send(ACCESS_TOKEN);
                });
            } else {
                resApi.status(428).send('الخطأ: هنالك تحديث جديد للتطبيق يتوجب عليك تحميله');
            }

        });

    },
    userAutoLogin: (req, resApi) => {
        console.log('run auto login user');
        var os = req.body.os;
        var app_version = req.body.version;
        db.query(os == 'android' ? 'SELECT android_version FROM constants' : 'SELECT ios_version FROM constants', (err, res) => {
            if (err) {
                console.log(err);
            }
            var server_version = os == 'android' ? res.rows[0].android_version : res.rows[0].ios_version;
            console.log('app_version is:' + app_version);
            console.log('server_version is:' + server_version);
            console.log('compareVersions(server_version, app_version) is:' + compareVersions(server_version, app_version));
            var is_need_update = compareVersions(server_version, app_version) > 0;
            if (!is_need_update) {
                resApi.sendStatus(200);
            } else {
                resApi.status(428).send('الخطأ: هنالك تحديث جديد للتطبيق يتوجب عليك تحميله');
            }

        });


    },

    deleteUser: (req, resApi) => {
        executeQuery("DELETE FROM users_suggestions WHERE id_user=" + req.payload.id);
        executeQuery("DELETE FROM users_info WHERE id=" + req.payload.id, resApi);
        //                           db.query("SELECT id_bus from drivers_info where id=" + req.params.id, (err, res) => {
        //                             if (err)  {console.log(err);}
        //                             console.log(res.rows.length);
        //                             if(res.rows.length>0){
        //                               db.query("delete from buses_info where id=" + res.rows[0].id_bus, (err, res) => {
        //                                 if (err)  {console.log(err);}
        //                                   db.query("delete from drivers_info where id=" + req.params.id, (err, res) => {
        //                                       if (err)  {console.log(err);}
        //                                       resApi.send("done");
        //                                   });
        //                               });
        //                               }else{
        //                               resApi.sendStatus(204);
        //                               }
        //                           });
    },
    userInitMap: (req, resApi) => {
        const id_user = req.payload.id;
        const id_route = req.body.id_route;
//        selectQuery("select * from routes_info where id=" + id_route,resApi);
        db.query("select * from routes_info where id=" + id_route, (err, res) => {
            if (err) {
                console.log(err);
            }
//            const path = res.rows[0].path;
//            const coord = res.rows[0].coord;
//            const zoom = res.rows[0].zoom;
//            resApi.json({
//                "id_user": id_user,
//                "path": path,
//                "coord": coord,
//                "zoom": zoom,
//                "buses_temp_info": tempInfo.getBusesTempInfo(id_route),
//            });
//        });

            resApi.json({
                "user": {"id_user": id_user},
                "route": res.rows,
                "buses_temp_info": tempInfo.getBusesTempInfo(id_route)
            });
        });
    },
    driverInitMap: (req, resApi) => {
        const id_route = req.body.id_route;
        resApi.json({
            "users_temp_info": tempInfo.getUsersTempInfo(id_route),
            "buses_temp_info": tempInfo.getBusesTempInfo(id_route)
        });

    }, sendPushToAllUsers: (req, resApi) => {
        console.log("run sendPushForAllUsers");
        var payload = {
            notification: {
                title: req.body.title,
                body: req.body.body
            }
        }
admin.messaging().sendToTopic(req.body.topic,payload);
        resApi.send("ok");
    },
    sendPushToRoute: (req, resApi) => {

        // console.log("run sendPushToRoute");
        db.query("SELECT push_token FROM buses_info WHERE LENGTH(push_token)>30 and id_route=" + req.body.id_route, (err, res) => {
            if (err) {
                console.log(err);
            }
            const registrationTokens=[];
            for (var i = 0; i < res.rows.length; i++) {
                var push_token = res.rows[i].push_token;
                registrationTokens.push(push_token);
            }
            const message = {
                data: {score: '850', time: '2:45'},
                tokens: registrationTokens,
                notification: {
                    title: req.body.title,
                    body: req.body.body
                },
            };

            admin.messaging().sendMulticast(message)
                .then((response) => {
                    if (response.failureCount > 0) {
                        const failedTokens = [];
                        response.responses.forEach((resp, idx) => {
                            if (!resp.success) {
                                failedTokens.push(registrationTokens[idx]);

                            }

                        });
                        console.log('List of tokens that caused failures: ' + failedTokens);
                        resApi.send('List of tokens that caused failures: ' + failedTokens);
                    }
                    resApi.send("ok");
                });




        });

    },
    sendFeedBack: (req, resApi) => {

        insertIntoUniqeTable(req, resApi, "feedback", {
            "date": req.body.date,
            "type": req.body.type,
            "token": req.body.token,
            "push_token": req.body.push_token,
            "rate": req.body.rate,
            "msg": req.body.msg

        });
    },
}
//----------------------------------------------------


//------------------------------------------------
function createIdForTable(tableName) {
    const sql = 'select count(*) from ' + tableName;
    return new Promise((resolve, reject) => {
        db.query(sql, (err, result) => {
            if (err) {
                return reject(err);
            }
            resolve(result);
        });
    });
}

function executeQuery(sql, resApi) {
    db.query(sql, (err, res) => {
        if (err) {
            console.log(err);
        }
        if (isDefined(resApi)) {
            resApi.send("done");
        }

    });
}

function isDefined(value) {
    return typeof value != 'undefined';
}

function selectQuery(sql, resApi) {
    db.query(sql, (err, res) => {
        if (err) {
            console.log(err);
        }
        resApi.send(res.rows);
    });
}

function insertIntoTable(req, resApi, tableName, jsonArray) {
    createIdForTable(tableName).then((result) => {
        const id = (parseInt(result.rows[0].count) + parseInt(1));
        let columns = "id";
        let numbers = "$1";
        let iter = 2;
        let params = [id];

        for (var k in jsonArray) {
            params.push(jsonArray[k]);
            columns += "," + k;
            numbers += ",$" + iter;
            iter += 1;
        }
        const sql = "INSERT INTO " + tableName + "(" + columns + ") values(" + numbers + ");";
        db.query(sql, params, (err, res) => {
            if (err) {
                console.log(err);
            }
            resApi.send("done");
        });
    }).catch((err) => {
        {
            console.log(err);
        }
    });
}

function insertIntoUniqeTable(req, resApi, tableName, json) {
    var keys;
    var values;
    if (json != null) {
        keys = Object.keys(json);
        values = Object.values(json);
    } else {
        keys = Object.keys(req.body);
        values = Object.values(req.body);
    }
    var length = keys.length;
    var columns = (keys + "");
    var str = "";
    for (var i = 0; i < length; i++) {
        str += "'" + values[i] + "'";
        if (i != length - 1) {
            str += ",";
        }
    }
    var SQL = "INSERT INTO " + tableName + "(" + keys.toString() + ") VALUES(" + str + ");"
    // console.log(SQL);
    executeQuery(SQL, resApi);
}

function sendSMSToPhone(sms, phone) {
    request.post('https://platform.releans.com/api/message/send').form({
        senderId: 'VZ7k1oYq9wdL8nrdjPXgEBG3Q',
        message: sms,
        mobileNumber: phone
    }).auth(null, null, true, 'd9b6a5f3bfb3e99a55e9482ca79cb1a3');
}

function sendPushNotification(title,body,token){

    const message = {
        data: {score: '850', time: '2:45'},
        notification: {
            title: title,
            body: body
        },
    };

    admin.messaging().sendToDevice(token, message)
        .then(function(response) {
            console.log("Successfully sent message:", response);
        })
        .catch(function(error) {
            console.log("Error sending message:", error);
        });

}
