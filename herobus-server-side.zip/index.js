'use strict';
const service =
    ('./App/Service/service')
const tempInfo = require('./App/Entity/TempInfo');
const express = require('express');
const socketIO = require('socket.io');
const controller = require('./App/Controller/controller');
const cron = require('node-cron');
const https = require('https');
const PORT = process.env.PORT || 8080;
const INDEX = '/index.html';
var admin = require("firebase-admin");
var serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

//cron.schedule('*/4 * * * *', publish());
//function  publish(){
//console.log('run schedule function');
////////return true;
//}


const {
    Client
} = require('pg');
const db = new Client({
    user: "biapwskdrvyjfh",
    password: "fd0bcc9345f8e1123b54531c40199903d370c370844ab9034aca1876d763d378",
    host: "ec2-54-155-226-153.eu-west-1.compute.amazonaws.com",
    port: "5432",
    database: "dfrogsh6j94e5v",
    ssl: {
        rejectUnauthorized: false
    }
});
db.connect();

const server = express()
    .use([express.urlencoded({
        extended: true
    }), express.json()])
    .use("/app", controller)
    .use("/", (req, res) => res.sendFile(INDEX, {
        root: __dirname
    }))
    .listen(PORT, () => console.log(`Listening on ${PORT}`));
const io = socketIO(server);


io.on('connection', function(socket) {
//console.log('socket.request.headers.id_route:'+socket.request.headers.id_route);
    if(socket.handshake. query.id_route!='routes'&&socket.request.headers.id_route!=null){
        socket.id_auth = socket.request.headers.id + "";
        socket.id_route = socket.request.headers.id_route + "";
        socket.account_type = socket.request.headers.type + "";
        socket.lat = socket.request.headers.lat + "";
        socket.lng = socket.request.headers.lng + "";
        socket.rotate = socket.request.headers.rotate + "";
        socket.running = "متحرك";
        socket.speed = "0";


//    console.log('socket.id:' + socket.request.headers.id);
//    console.log('socket.id_route:' + socket.request.headers.id_route);
//    console.log('socket.account_type:' +  socket.request.headers.type);
//    console.log('-----------------------------');
//    socket.id_route='1';

        console.log('There is new connected ' + socket.id + ' and type ' + socket.account_type+ ' and id_auth ' + socket.id_auth);
        socket.join(socket.id_route);
if(socket.id_auth!=null&&socket.id_auth !== 'undefined') {


    socket.on('disconnect', () => {

        if (socket.account_type == "user") {
            console.log('disconnected ' + "user." + socket.id_auth);
            io.sockets.in(socket.id_route).emit('map_users', {
                action: "delete",
                id: "user." + socket.id_auth,
                lat: "",
                lng: ""
            });
            tempInfo.deleteUser(socket.id_route, "user." + socket.id_auth,);
        } else {
            io.sockets.in(socket.id_route).emit('map_drivers', {
                action: "delete",
                id: "bus." + socket.id_auth,
                lat: "",
                lng: ""
            });
            tempInfo.deleteDriver(socket.id_route, "bus." + socket.id_auth,);

            db.query("UPDATE buses_info set is_work_now=false where id=" + socket.id_auth , (err, res) => {
                if (err) {
                    console.log(err);
                }
                console.log("UPDATE routes_info set current_work_buses=(select count(*) from buses_info where id_route=" + socket.id_route + " and is_work_now='true') where id=" + socket.id_route + " RETURNING current_work_buses;");


                db.query("UPDATE routes_info set current_work_buses=(select count(*) from buses_info where id_route=" + socket.id_route + " and is_work_now='true') where id=" + socket.id_route + " RETURNING current_work_buses;", (err, res) => {
                    if (err) {
                        console.log(err);
                    }
                    // console.log({action: "update",id: socket.id_auth,current_work_buses: res.rows[0].current_work_buses});

                    io.sockets.in('routes').emit('update_data', {
                        action: "update",
                        id_route: socket.id_route,
                        current_work_buses: res.rows[0].current_work_buses
                    });
                    socket.leave('routes');
                });
            });

        }
        socket.leave(socket.id_route);

    });
    socket.on('map_users', function (data) {
        console.log('run socket.on map_users');
        io.sockets.in(socket.id_route).emit('map_users', {
            action: "update",
            id: "user." + socket.id_auth,
            lat: data.lat,
            lng: data.lng
        });
        console.log('socket.id:' + socket.id);
        if (socket.id.toString().includes('.'))
            tempInfo.addOrUpdateUser(socket.id_route, socket.id, data.location);
    });
    socket.on('map_drivers', function (data) {
        // console.log(data);
        io.sockets.in(socket.id_route).emit('map_drivers', {
            action: "update",
            id: "bus." + socket.id_auth,
            lat: data.lat,
            lng: data.lng,
            rotate: data.rotate,
            running: data.running,
            speed: data.speed
        });
//            tempInfo.addOrUpdateDriver(socket.id_route,  "bus." +socket.id_auth,'B'+socket.id_auth+','+socket.lat+','+socket.lng+','+socket.rotate+','+socket.running);

        tempInfo.addOrUpdateDriver(socket.id_route, "bus." + socket.id_auth, 'B' + socket.id_auth + ',' + data.lat + ',' + data.lng + ',' + data.rotate + ',' + data.running + ',' + data.speed);
    });

    if (socket.account_type == "user") {
        io.sockets.in(socket.id_route).emit('map_users', {
            action: "add",
            id: "user." + socket.id_auth,
            lat: socket.lat,
            lng: socket.lng
        });
        tempInfo.addOrUpdateUser(socket.id_route, "user." + socket.id_auth, socket.lat + ',' + socket.lng);
    } else {

            socket.join('routes');
        if(socket.id_auth!=null&&socket.id_auth !== 'undefined') {
            io.sockets.in(socket.id_route).emit('map_drivers', {
                action: "add",
                id: "bus." + socket.id_auth,
                lat: socket.lat,
                lng: socket.lng,
                rotate: socket.rotate,
                speed: socket.speed
            });
            tempInfo.addOrUpdateDriver(socket.id_route, "bus." + socket.id_auth, 'B' + socket.id_auth + ',' + socket.lat + ',' + socket.lng + ',' + socket.rotate + ',' + socket.running + ',' + socket.speed);

            console.log("UPDATE buses_info set is_work_now=true where id=" + socket.id_auth );
            db.query("UPDATE buses_info set is_work_now=true where id=" + socket.id_auth , (err, res) => {
                if (err) {
                    console.log(err);
                }
                // console.log("UPDATE routes_info set current_work_buses=(select count(*) from buses_info where id_route=" + socket.id_route + " and is_work_now='true') where id=" + socket.id_route + " RETURNING current_work_buses;")
                db.query("UPDATE routes_info set current_work_buses=(select count(*) from buses_info where id_route=" + socket.id_route + " and is_work_now='true') where id=" + socket.id_route + " RETURNING current_work_buses;", (err, res) => {
                    if (err) {
                        console.log(err);
                    }
//                           console.log(
//
//                            {action: "update",id: socket.id_auth,current_work_buses: res.rows[0].current_work_buses});

                    io.sockets.in('routes').emit('update_data', {
                        action: "update",
                        id_route: socket.id_route,
                        current_work_buses: res.rows[0].current_work_buses
                    });
                });
            });
        }
    }
}
    }else{
        socket.join('routes');

        console.log('There is new connected for routes socket '+socket.id);
        socket.on('disconnect', () =>{
            socket.leave('routes');
            console.log('disconnected for routes socket '+socket.id);
        });
    }


});
cron.schedule('0 */4 * * *', function() {
 console.log('running a task every minute');
 https.get('https://freeflutter.herokuapp.com/publishnewpost');

});

// server.on('uncaughtException', function (req, res, route, err) {
//     log.info('******* Begin Error *******\n%s\n*******\n%s\n******* End Error *******', route, err.stack);
//     if (!res.headersSent) {
//         return res.send(500, {ok: false});
//     }
//     res.write('\n');
//     res.end();
// });

// process.on('uncaughtException', function (err,eew) {
//     console.log('******* Begin Error *******\n%s\n*******\n%s\n******* End Error *******', eew, err.stack);
//     if (!res.headersSent) {
//         return res.send(500, {ok: false});
//     }
//     res.write('\n');
//     res.end();
// });
module.exports = server;